---
title: Blog
content:
    items: '@self.children'
    limit: 5
    order:
        by: default
        dir: desc
    pagination: true
    url_taxonomy_filters: false
---

Welcome to my blog about game development!

**Who are you?** I'm Pandaqi, an indie game developer creating local multiplayer games for families. 

**What does that mean?** I make games for 1-4 players on the same phone/computer, designed to be playable by children, parents, grandparents, non-gamers, anyone!

**What can I find here?** I usually write "devlogs" or "diaries" about every game I make. Here I share the problems I faced, the lessons I learned, which choices I made (and why), etcetera. Hopefully it's interesting, inspiring and educational to read! (Sometimes I also write general articles about games.)