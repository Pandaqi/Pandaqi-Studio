---
title: 'My Thoughts on Game Design Documents'
published: false
---

Lala

What I think of game design documents. How I tried to make them work for years, but eventually found out I'm just not made for that kind of workflow. (Use metaphor of architect vs gardener writers?)

Explain my current workflow (and things I tried in the past; what worked and didn't work)

And explain things you COULD try (what I think would work well) if you do want to work with design documents.