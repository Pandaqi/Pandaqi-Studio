---
title: Miscellaneous
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
date: '31-03-2021 23:41'
---

This page contains all my articles that didn't fit in any other series/category/devlog.