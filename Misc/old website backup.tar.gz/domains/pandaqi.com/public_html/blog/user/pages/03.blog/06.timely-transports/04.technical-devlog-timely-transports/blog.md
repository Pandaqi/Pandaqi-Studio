---
title: '[Technical Devlog] Timely Transports'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

This section contains the _technical devlog_ for Timely Transports. Here I explain how I made both the **random board generation** (how I create a random map you can print, which is actually balanced and good-looking) and **digital component** (the timers you use during gameplay).