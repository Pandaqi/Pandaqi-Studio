---
title: 'Game Engine Reviews'
content:
    items: '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: false
---

This article contains an overview of all my reviews for Game Engines! 

Many websites just include an endless list of pros and cons, or buzzwords like "flexible" and "fast", which doesn't help at all when choosing an engine. Additionally, I like to experiment and innovate, and think that trying different engines will lead to more creative and new ideas.

That's why I write these reviews. (Currently there's only a single review, but reviews for Godot, Gideros and Defold are underway.)