---
title: '[Devlog] Unstable Universe'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

Contains the _devlog_ for Unstable Universe, the first every boardgame where you're allowed to cut into the board! Explains the process behind it, the ideas, the obstacles, the lessons learned.