---
title: '[Technical Devlog] Wondering Witches'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

My _technical devlog_ for Wondering Witches. Explains how I built the computer component that is necessary for the game. (It generates a random recipe, adds buttons to check it, generates a random starting setup if you want, and more.)