# v2.0.1
## 12/21/2018

1. [](#bugfix)
  * Fire `onPageInitialized` later as it breaks on-page forms
  * Fixed a spelling error

# v2.0.0
## 01/01/2015

1. [](#improved)
    * Uses Grav cache internally to store assets
    * Works with modular pages now too
1. [](#bugfix)
    * Actually works with page cache enabled now

# v1.2.1
## 10/07/2015

1. [](#bugfix)
    * Fixed a bug with inline CSS and JS

# v1.2.0
## 06/23/2015

1. [](#new)
    * Support for multiple items
    * added ability to use Grav page refs and local assets + page enable override

# v1.0.4
## 02/05/2015

1. [](#improved)
    * REGEX optimizations
    * Code improvements

# v1.0.3
## 01/23/2015

1. [](#improved)
    * Changed event to utilize new `onPageContentRaw()` -> requires Grav 0.9.14+
    * Added admin checks
    * PSR fixes

# v1.0.2
## 11/30/2014

1. [](#new)
    * ChangeLog started...
