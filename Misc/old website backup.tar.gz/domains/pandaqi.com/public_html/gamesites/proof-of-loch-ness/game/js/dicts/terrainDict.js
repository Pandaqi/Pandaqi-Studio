// all edge types (in correct order): "river", "shrub", "wall", "road"
// all weather types (in correct order): "regular", "rain", "heat", "snow", "thunder", "windy", "freezing"


var TERRAINS = {
	"grassland": {
		weather: [{type:"regular", weight: 6}, {type: "rain", weight: 2}],
		edges: ["river", "shrub", "wall"],

		possibleAnimals: [],
	},

	"desert": {
		weather: [{type:"regular", weight: 3}, {type:"heat", weight: 6}],
		edges: [],

		possibleAnimals: [],
	},

	"forest": {
		weather: [{type:"regular", weight: 2}, {type: "rain", weight: 2}],
		edges: ["river", "shrub"],

		useOverlayTerrain: true,
		overlayTerrainLine: 0.0,
		forbidOverlayOnWater: true,
		waterLine: -0.1,

		forbidWaterSources: true,

		possibleAnimals: ['Fish']
	},

	"lake": {
		weather: [{type:"regular", weight: 1}],
		edges: [],

		forbidWaterSources: true,
		possibleAnimals: ['Fish']
	},

	"rainforest": {
		weather: [{type:"regular", weight: 1},{type:"rain", weight: 7}],
		edges: [],
		useOverlayTerrain: true,
		overlayTerrainLine: -0.3,
		waterLine: -0.4,

		possibleAnimals: [],
	},

	"swamp": {
		weather: [{type:"regular", weight: 1}],
		edges: [],
		waterLine: 0.075,

		possibleAnimals: [],
	},

	"mountain": {
		weather: [{type:"regular", weight: 2}, {type:"snow", weight: 6}, {type:"freezing", weight: 3}],
		edges: [],

		mountainLine: 0.2,

		possibleAnimals: [],
	},

	"urban": {
		weather: [{type:"regular", weight: 1}],
		edges: [],
		useOverlayTerrain: true,
		overlayTerrainLine: 0.3,
		waterLine: -1.0,

		grassLine: -0.2,

		possibleAnimals: []
	},
}