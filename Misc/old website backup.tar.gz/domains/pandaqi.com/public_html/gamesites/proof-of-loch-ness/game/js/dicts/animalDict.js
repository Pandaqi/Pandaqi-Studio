var ANIMAL_DICT = {
	"Fish": {
		frame: 0,
		locationRequirements: { "water": true },
		moving: {},
		move: function() {
			var nbs = MAP.getValidNeighbours(this.pos, { 'forcedWater': true });
			if(nbs.length <= 0) { return; }

			var newPos = nbs[Math.floor(Math.random() * nbs.length)];

			this.setPos(newPos);
		}
	}
}