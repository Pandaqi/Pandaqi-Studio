class Animal extends Entity {
	constructor(id, type) {
		super(type);

		this.entityType = "animal";

		this.id = id;
		this.pos = { x: -1, y: -1 }
		this.sprite = null;

		this.wounded = false;
		this.dead = false;

		// copy all properties from animal configuration/dictionary
		// directly onto the object
		var props = ANIMAL_DICT[type];

		this.move = props.move.bind(this);

		for(key in props) {
			this[key] = props[key];
		}
	}

	receiveAttack(kill = false) {
		// if we're already wounded, or the attack is insta-kill, we're dead
		if(this.wounded || kill) { this.dead = true; return; }

		// otherwise, only wound us
		// TO DO: some sort of fleeing behaviour? Or is this becoming too complex?
		this.wounded = true;
	}

	setPos(pos, params = {}) {
		if(this.dead) { return; } // dead animals can't walk, duh
		if(this.wounded && Math.random() > 0.5) { return; } // wounded animals walk slower

		super.setPos(pos, params);
	}
}