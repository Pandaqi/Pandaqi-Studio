<?php
	require '../../default_headers.php';
?>
		<title>The Proof of Loch Ness &mdash; tracking mythical monsters that might not even exist</title>
		<link rel="icon" type="image/png" href="gamesites/proof-of-loch-ness/favicon.png" />

		<!-- Header Font: Ravi Prakash -->
		<!-- Body Font: Roboto Condensed -->
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Ravi+Prakash&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,300;0,400;0,700;1,400;1,700&display=swap" rel="stylesheet"> 

		<!-- Default CSS stylesheet for all boardgame pages -->
		<link rel="stylesheet" type="text/css" href="gamesites/boardgames/boardGameStyles.css">

		<!-- Custom CSS for this page -->		
		<style type="text/css">
			h1,h2,h3,h4,h5,h6 {
				font-family: 'Ravi Prakash';
			}

			body {
				font-family: 'Roboto Condensed';
			}
		</style>
	</head>

	<body>
		<main>
			<section>
				<!-- <img src="https://i.imgur.com/7qpyA55.png" class="bigHeaderImage" /> -->
				<div class="autoCenter">
					<h1>The Proof of Loch Ness</h1>
					<p class="tagline" style="position: relative; background-color: #DFF2D8; padding: 20px; border-radius: 10px;">TO DO</p>
					<p class="tagline taglineData">Ages: everyone | Complexity: Low | Playtime: 30 minutes </p>
					<p style="text-align: center;"><a href="#" class="btn download-btn">Download</a></p>
				</div>
			</section>

		    <!-- Game settings + button to start game interface on phone -->
			<section>
				<div class="autoCenter">
					<a name="game"></a>
					<h2>Game</h2>
					<p>Input your desired settings, click the button, start!</p>

					<div id="gameSettings">
						<div>
							<div>
								<label for="setting-playerCount">Number of Players? </label>
								<select name="setting-playerCount" id="setting-playerCount">
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
								</select>
								
								<label for="setting-scenario">Scenario? </label>
								<select name="setting-scenario" id="setting-scenario">
									<option value="Uni">Unicorn Park</option>
									<option value="Desert">Desert Drama</option>
									<option value="Nessie">Loch Ness</option>
									<option value="Forest">Footprint Forest</option>
									<option value="Platypus">Platypus</option>
								</select>

								<label for="setting-monster">Monster? </label>
								<select name="setting-monster" id="setting-monster">
									<option value="Preferred">-- Preferred --</option>
									<option value="Unicorn">Unicorn</option>
									<option value="Cactus Cat">Cactus Cat</option>
									<option value="Nessie">Nessie</option>
									<option value="Bigfoot">Bigfoot</option>
									<option value="Platypus">Platypus</option>
								</select>

								<div class="settingRemark">Leave it on "preferred" to play the default monster for your chosen scenario.</div>
							</div>
						</div>
					</div>

					<p style="text-align: center;">
						<button class="btn" id="startGameBtn">Start Game</button>
					</p>

					<script>
						document.getElementById('startGameBtn').addEventListener('click', function(ev) {
							// read input
							var playerCount = parseInt( document.getElementById('setting-playerCount').value );
							var scenario = document.getElementById('setting-scenario').value;
							var monster = document.getElementById('setting-monster').value;

							// save in local storage
							window.localStorage.setItem('playerCount', playerCount);
							window.localStorage.setItem('scenario', scenario);
							window.localStorage.setItem('monster', monster);

							// go to actual game page
							window.open("gamesites/proof-of-loch-ness/game/index.php", "_blank")
						});
					</script>
				</div>
			</section>

			<section>
				<div class="autoCenter">
					<h2>Picture Book</h2>
					<p>This game inspired me to create an <em>interactive picture book</em>, which is published in the Netherlands. If you're Dutch, be sure to check it out: <a href="#">TO DO: Link here (Het Bewijs van Loch Ness)</a></p>
				</div>
			</section>

			<section>
				<div class="autoCenter">
					<h2>Feedback</h2>
					<p>Lala</p>
				</div>
			</section>

			

		</main>

		

<?php

require '../../footer.php';

?>

		