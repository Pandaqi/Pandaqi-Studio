// actual game
const MainGame = new Phaser.Class({

    Extends: Phaser.Scene,

    initialize:
    function MainGame()
    {
        Phaser.Scene.call(this, { key: 'mainGame' });
    },

    preload: function() {
    	// shows text that the game is loading
        var textCfg = 
		{
			fontFamily: 'Rowdies', 
			fontSize: '48px',
			color: '#DDDDDD', 
			stroke: '#111111',
			strokeThickness: 4,
		}

        this.loadingStateText = this.add.text(this.sys.game.canvas.width / 2, this.sys.game.canvas.height / 2, "Loading Game ...", textCfg);
        this.loadingStateText.setOrigin(0.5, 0.5);

    	// sets some settings I somehow need in most cases
		this.load.crossOrigin = 'Anonymous';
		this.canvas = this.sys.game.canvas;

		// loads all that stuff
		var base = '';

		this.load.spritesheet('timer_bar', base + 'timer_bar.png?cc=1', { frameWidth: 10, frameHeight: 10 });

		this.load.image('upgrade_button', base + 'upgrade_button.png?cc=1');

		this.load.spritesheet('vehicle_icons', base + 'vehicle_icons.png?cc=4', { frameWidth: 400, frameHeight: 400 });

		this.load.audio('alarm_1', base + 'alarm_1_short.mp3', { instances: 4 });
		this.load.audio('announcement_1', base + 'announcement_1.mp3', { instances: 2 });
		this.load.audio('timer_fail_1', base + 'timer_fail_1_short.mp3', { instances: 4 });
		this.load.audio('score_success_1', base + 'score_success_1.mp3', { instances: 8 });
		this.load.audio('upgrade_1', base + 'upgrade_1_short.mp3', { instances: 2 });
		this.load.audio('victory_1', base + 'victory_1_short.mp3', { instances: 1 });

		this.load.spritesheet('goods', base + 'goods.png?c=1', { frameWidth: 100, frameHeight: 100 });

		const url = 'rexbbcodetextplugin.min.js';
		this.load.plugin('rexbbcodetextplugin', url, true);

		var loadJungleAmbience = (parseInt(window.localStorage.playerRank) === 1);
		if(loadJungleAmbience) {
			console.log("Loading jungle ambience!")

			// this is a softer, less present one
			//const url2 = "https://www.zapsplat.com/wp-content/uploads/2015/sound-effects-31172/zapsplat_nature_forest_ambience_distant_river_dist_planes_birds_32171.mp3?_=8";

			// this one is more present
			// https://www.zapsplat.com/wp-content/uploads/2015/sound-effects-free-to-use-sounds/ftus_jungle_rainforest_daytime_birds_singing_close_up_distant_traffic_vietnam_705.mp3?_=7

			this.load.audio('ambience', 'jungle_ambience_2.mp3');
		}
	},

	prepareCities: function() {
		const maxCities = PLAYERCOUNT_TO_CITYCOUNT[this.cfg.playerCount];
		this.cityNames = CITY_NAMES.splice(0, maxCities)
	},

	prepareGoods: function() {
		// Determine total good probability (for proper drawing of random goods)
		const gameDifficulty = DIFFICULTY_LEVELS[this.cfg.difficulty];
		this.totalGoodProbability = 0;
		for(name in GOODS) {
			const goodDifficulty = DIFFICULTY_LEVELS[GOODS[name].difficulty] || "Training Wheels";
			if(goodDifficulty > gameDifficulty) {
				delete GOODS[name];
				continue;
			}

			this.totalGoodProbability += GOODS[name].prob;
		}

		this.activeGood = null
	},

	prepareUpgrades: function() {
		this.upgradesAreInTheGame = true;
		if(DIFFICULTY_LEVELS[this.cfg.difficulty] < DIFFICULTY_LEVELS["Another Upgrade"]) {
			this.upgradesAreInTheGame = false;
			return;
		}
	},

	create: function() {
		// remove whatever we used during game loading
		this.loadingStateText.destroy();

		// determine if we're on a nice phone or a wide-screen landscape mode (probably computer or tablet)
		this.portraitMode = true;
		if(this.canvas.width > this.canvas.height && this.canvas.width > 600) {
			this.portraitMode = false;
		}

		// grab configuration from settings input (localStorage)
		// add general timing settings to it
		this.cfg = {
			'difficulty': window.localStorage.difficulty || "Training Wheels",
			'playerRank': parseInt(window.localStorage.playerRank || 0),
			'playerCount': parseInt(window.localStorage.playerCount || 4),
			'timeout': parseInt(window.localStorage.timeout || 0),
			'pointsToWin': 30,

			'minGoodTimer': 35,
			'maxGoodTimer': 80,
			'goodRunoutTime': 15,
		}

		this.cfg.goodsEnabled = (DIFFICULTY_LEVELS[this.cfg.difficulty] > 0);
		this.cfg.planesAndTrainsDisabled = (DIFFICULTY_LEVELS[this.cfg.difficulty] < 2);

		this.previousTimeout = 0;

		

		// load jungle ambience on first player
		if(this.cfg.playerRank == 1) {
			var backgroundMusicCfg = {
			    mute: false,
			    volume: 0.5,
			    rate: 1,
			    detune: 0,
			    seek: 0,
			    loop: true,
			    delay: 0
			}

			this.sound.add('ambience', backgroundMusicCfg).play();
		}
		

		this.prepareCities();
		this.prepareGoods();
		this.prepareUpgrades();

		this.timers = {};
		this.score = 0;

		this.iconList = {};

		this.upgradeCost = 4;

		this.createScoreText();
		this.createIconList();

		this.createGlobalTimer();

		this.determineWindowSizing();
		this.createEventWindow();
		this.createGoodWindow();

		this.createWaitingScreen();
	},

	createGlobalTimer: function() {
		this.globalTimerText = null;
		this.globalTimerVal = 0;

		if(this.cfg.playerCount > 1) {
			return;
		}

		var fontSize = 48;
		var textCfg = 
		{
			fontFamily: 'Rowdies', 
			fontSize: fontSize + 'px',
			color: '#DDDDDD', 
			stroke: '#111111',
			strokeThickness: 4,
		}

		if(!this.portraitMode) {
			textCfg.fontSize = 0.5*fontSize + 'px';
		}

		this.globalTimerVal = 20*60

		var txt = this.add.text(this.canvas.width, this.scoreText.y, this.convertSecondsToString(this.globalTimerVal), textCfg);
		txt.setOrigin(1.0, 0.5);
		
		this.globalTimerText = txt
	},

	convertSecondsToString(s) {
		var minutes = Math.floor(s / 60);
		if(minutes < 10) {
			minutes = "0"+minutes;
		}

		var seconds = Math.ceil(s) % 60
		if(seconds < 10) {
			seconds = "0"+seconds
		}

		return minutes + ":" + seconds;
	},

	createWaitingScreen: function() {
		this.gamePaused = true;

		// create a small "waiting screen" => we need one user click/input before we can autoplay sounds
		var sc = this.add.sprite(0, 0, 'timer_bar', 0);
		sc.displayWidth = this.canvas.width;
		sc.displayHeight = this.canvas.height;
		sc.setOrigin(0,0);
		sc.depth = 12000;

		var ths = this;
		sc.setInteractive();
		sc.on('pointerdown', function() {
			ths.startGame();
		})

		var textCfg = 
		{
			fontFamily: 'Rowdies', 
			fontSize: '36px',
			color: '#111111', 
		}

		var txt = this.add.text(0.5*sc.displayWidth, 0.5*sc.displayHeight, 'Click anywhere to start', textCfg);
		txt.setOrigin(0.5, 0.5);
		txt.depth = 12000;

		textCfg.fontSize = '24px';
		textCfg.color = '#555555';

		var subTxt = this.add.text(txt.x, txt.y + 0.5*(36 + 24) + 5, '(wait until everyone is ready)', textCfg);
		subTxt.setOrigin(0.5, 0.5);
		subTxt.depth = 12000;

		this.waitingScreen = { 'bg_sprite': sc, 'text': txt, 'subText': subTxt }
	}, 

	startGame() {
		// completely destroy waiting screen (will never need it again)
		this.stopTimeout();

		this.gamePaused = false;

		// automatically add a good at the start
		if(this.cfg.goodsEnabled) {
			this.addGood();
		}
	},

	convertVehicleToFrame: function(name) {
		return VEHICLE_MAP[name].frame || -1;
	},

	convertFrameToVehicle: function(frame) {
		for(name in VEHICLE_MAP) {
			if(VEHICLE_MAP[name].frame == frame) {
				return name;
			}
		}

		return 'nonexistent vehicle';
	},

	determineWindowSizing: function() {
		var minWindowHeight = 96*2;
		if(!this.portraitMode) {
			minWindowHeight = 48*2;
		}

		var maxWindowHeight = minWindowHeight*2.5;

		// this is the exact space we have between the timer at the top + icons at the bottom
		var desiredVal = this.iconList['jeep'].y - 0.5*this.iconDisplaySize - this.scoreText.getBottomCenter().y;

		// then we need to clamp it between minimum and maximum window height
		var maxDesiredVal = Math.max(desiredVal, minWindowHeight);
		var finalDesiredVal = Math.min(maxWindowHeight, maxDesiredVal);
		this.maxWindowHeight = finalDesiredVal;

		// finally, we set the correct Y position according to this window size
		this.windowPositionY = this.scoreText.getBottomCenter().y + 0.5*this.maxWindowHeight
	},

	createEventWindow() {
		// events are only added to the game at difficulty level "Extraordinary Events"
		this.eventsAreInTheGame = true;
		if(DIFFICULTY_LEVELS[this.cfg.difficulty] < DIFFICULTY_LEVELS["Extraordinary Events"]) {
			this.eventsAreInTheGame = false;
			return;
		}

		// also, some events are only included in later difficulty levels (such as Rubber madness stuff), so filter those out
		const gameDifficulty = DIFFICULTY_LEVELS[this.cfg.difficulty];
		this.totalEventProbability = 0
		for(name in EVENTS) {
			const eventDifficulty = DIFFICULTY_LEVELS[EVENTS[name].difficulty] || "Training Wheels";
			if(eventDifficulty > gameDifficulty) {
				delete EVENTS[name];
				continue;
			}

			this.totalEventProbability += EVENTS[name].prob
		}

		// then create the actual event window and timers
		this.activeEvent = null;
		this.eventTimer = 0;
		this.maxEventTimer = 0;

		var maxWidth = 1000;
		var margin = 10;

		// create background window 
		var bg_sprite = this.add.sprite(0.5*this.canvas.width, this.windowPositionY, 'timer_bar', 0);
		bg_sprite.setOrigin(0.5, 0.5);
		bg_sprite.displayWidth = this.canvas.width;
		bg_sprite.displayHeight = this.maxWindowHeight
		bg_sprite.depth = 2;

		if(!this.portraitMode) {
			bg_sprite.displayWidth = 800;
		}

		// create timer that shows when event will run out
		var topPos = bg_sprite.getTopLeft();
		var bar = this.add.sprite(topPos.x, topPos.y, 'timer_bar', 0);
		bar.setOrigin(0, 0);
		bar.displayWidth = bg_sprite.displayWidth;
		bar.displayHeight = bg_sprite.displayHeight;
		bar.depth = 2.5;
		bar.setTint(0xFFFF00);

		// create overlaid text
		var textCfg = 
		{
			fontFamily: '"Yanone Kaffeesatz"', 
			fontSize: '96px',
			color: '#111111',
			wrap: { 
				width: bg_sprite.displayWidth - margin*2, 
				useAdvancedWrap: true
			 } 
		}

		if(!this.portraitMode) {
			textCfg.fontSize = '48px';
		}

		var txt = this.add.rexBBCodeText(
			bg_sprite.x - 0.5*bg_sprite.displayWidth + margin, 
			bg_sprite.y - 0.5*bg_sprite.displayHeight + margin, 
			'Some Event Text Here', 
			textCfg
		);

		/*
		var txt = this.add.text(
			bg_sprite.x - 0.5*bg_sprite.displayWidth + margin, 
			bg_sprite.y - 0.5*bg_sprite.displayHeight + margin, 
			'Some Event Text Here', 
			textCfg
		);*/
		txt.depth = 3;


		this.eventWindow = { 'bg_sprite': bg_sprite, 'bar': bar, 'text': txt };

		this.hideEvent();
	},

	createGoodWindow() {
		this.goodTimer = 0;

		var maxWidth = 1000;
		var margin = 10;

		// create background window, sprite at left (which can flip frames to different goods), text
		var bg_sprite = this.add.sprite(0.5*this.canvas.width, this.windowPositionY, 'timer_bar', 0);
		bg_sprite.setOrigin(0.5, 0.5);
		bg_sprite.displayWidth = this.canvas.width;
		bg_sprite.displayHeight = this.maxWindowHeight
		bg_sprite.depth = 3;

		if(!this.portraitMode) {
			bg_sprite.displayWidth = 800;
		}

		// create timer that shows when good announcement will run out
		var topPos = bg_sprite.getTopLeft();
		var bar = this.add.sprite(topPos.x, topPos.y, 'timer_bar', 0);
		bar.setOrigin(0, 0);
		bar.displayWidth = bg_sprite.displayWidth;
		bar.displayHeight = bg_sprite.displayHeight;
		bar.depth = 3.5;
		bar.setTint(0xFFFF00);

		// this will display the actual good that's wanted
		var good_sprite = this.add.sprite(bg_sprite.x + 0.5*bg_sprite.displayWidth - margin, bg_sprite.y, 'goods', Math.floor(Math.random()*8));
		good_sprite.displayWidth = good_sprite.displayHeight = this.maxWindowHeight;
		good_sprite.setOrigin(1, 0.5);
		good_sprite.depth = 4;

		var textCfg = 
		{
			fontFamily: '"Yanone Kaffeesatz"', 
			fontSize: '96px',
			color: '#111111', 
		}

		if(!this.portraitMode) {
			textCfg.fontSize = '48px';
		}

		var txt = this.add.rexBBCodeText(
			bg_sprite.x - 0.5*bg_sprite.displayWidth + margin, 
			bg_sprite.y, 
			'Some New Good Text Here', 
			textCfg
		);

		/*
		var txt = this.add.text(
			bg_sprite.x - 0.5*bg_sprite.displayWidth + margin, 
			bg_sprite.y, 
			'Some New Good Text Here', 
			textCfg
		);*/

		txt.setOrigin(0, 0.5);
		txt.depth = 4;

		// listen for clicks (that will close the good message)
		var ths = this;
		bg_sprite.setInteractive();
		bg_sprite.on('pointerdown', function() {
			ths.removeGood(true);
		})

		this.goodWindow = { 'bg_sprite': bg_sprite, 'bar': bar, 'good_sprite': good_sprite, 'text': txt }

		// TO DO/DEBUGGING: re-enable this
		this.removeGood(true);
	},

	createScoreText: function() {
		var textCfg = 
		{
			fontFamily: 'Rowdies', 
			fontSize: '164px',
			color: '#FFFFFF', 
			stroke: '#111111',
			strokeThickness: 8,
		}

		if(!this.portraitMode) {
			textCfg.fontSize = '96px'
		}

		var ths = this;
		var margin = 20;

		var txt = this.add.text(0.5*this.canvas.width, 0 + margin, 'Score: 0', textCfg);
		txt.setOrigin(0.5, 0.0);

		txt.setInteractive();
		txt.on('pointerdown', function() {
			ths.updateScore(1);
		})

		this.scoreText = txt
	},

	updateScore: function(ds) {
		if(this.gamePaused) { return; }

		this.score += ds;
		this.scoreText.text = 'Score: ' + this.score;

		if(this.score >= this.cfg.pointsToWin) {
			this.sound.play('victory_1')
			this.scoreText.setColor('#00FF00');
			this.gamePaused = true;
			return;
		}

		if(ds >= 0) {
			this.sound.play('score_success_1');
		}
	},

	createIconList: function() {
		var vehicleTypes = ["jeep", "canoe", "trolly", "plane", 'tour bus', 'kayak', 'draisine', 'crane'];

		var cWidth = this.canvas.width;
		var cHeight = this.canvas.height;
		
		var iconsPerRow = 2;
		var totalNumRows = 2;
		var margin = 5;

		var offset = 0;
		var iconSize = cWidth / iconsPerRow;
		this.iconDisplaySize = iconSize - margin;

		// if our device is in landscape mode (probably a computer), "fake" portrait mode by setting a max width
		if(!this.portraitMode) {
			var maxWidth = 600
			iconSize = maxWidth / iconsPerRow;
			this.iconDisplaySize = iconSize - margin;

			offset = (cWidth - maxWidth) / 2;
		}
		
		var ths = this;

		for(var i = 0; i < 8; i++) {
			var name = vehicleTypes[i];

			// only create icons for first 4
			// (upgrades will switch their frames to the other types)
			if(i < 4) {
				var xIndex = i % iconsPerRow
				var yIndex = (totalNumRows - 1) - Math.floor(i/iconsPerRow)

				var x = offset + xIndex*iconSize + 0.5*iconSize;
				var y = cHeight - 0.5*iconSize - yIndex*iconSize
				var icon = this.add.sprite(x, y, 'vehicle_icons', this.convertVehicleToFrame(name));
				icon.displayWidth = icon.displayHeight = this.iconDisplaySize;
				icon.depth = 0;

				icon.myName = name;

				if(this.cfg.planesAndTrainsDisabled && i >= 2) {
					// if planes and trains are disabled
					// don't make their icons interactive or anything
					// in fact, hide them
					icon.setVisible(false);
				} else {
					icon.setInteractive();
					icon.on('pointerdown', function() {
						ths.iconClicked(this.myName);
					});
				}
				

				icon.upgraded = false;
				icon.canStartTimer = true;

				// the bar is what will get bigger and bigger as timer progresses
				// (NOTE: Anchor is x = 0, so it loads nicely to the right, but that needs different placement coordinates)
				var bar = this.add.sprite(x - 0.5*this.iconDisplaySize, y, 'timer_bar', 0);
				bar.displayWidth = 0;
				bar.displayHeight = this.iconDisplaySize;
				bar.setOrigin(0, 0.5);
				bar.depth = -1;

				icon.bar = bar;

				// the upgrade button is shown only when timer is in overtime, underneath icon
				var btn = this.add.sprite(x, y, 'upgrade_button');
				btn.displayWidth = this.iconDisplaySize;
				btn.displayHeight = (55/120) * btn.displayWidth;

				btn.y += btn.displayHeight; // to ensure it's fully beneath the icon
				btn.depth = 1; // and to ensure it's on top of everything
				btn.setVisible(false);

				icon.upgradeButton = btn

				btn.myName = name;
				btn.setInteractive();
				btn.on('pointerdown', function() {
					ths.upgradeVehicle(this.myName);
				})

				this.iconList[name] = icon;
			}

			// initialize all possible timers to null
			this.timers[name] = null;
		}
	},

	iconClicked: function(name) {
		var icon = this.iconList[name]
		var tm = this.timers[name]

		// if a timer is already running, TRY to stop the current timer
		if(!icon.canStartTimer || tm != null) {
			var success = (tm.overtime == true);
			this.stopTimer(name, success)

		// otherwise, start a new timer
		} else {
			this.startTimer(name);
		}
	},

	updateIconList: function() {
		for(name in this.iconList) {
			var icon = this.iconList[name];

			if(icon == null) {
				continue;
			}

			var tm = this.timers[name]

			if(tm == null) {
				icon.canStartTimer = true;
				icon.alpha = 1.0;

				//icon.bar.setFrame(0);
				icon.bar.setVisible(false);
				icon.upgradeButton.setVisible(false);
			} else {
				icon.canStartTimer = false;
				icon.alpha = 0.55;

				icon.bar.setVisible(true);
			}
		}
	},

	startTimer: function(name) {
		// determine length of timer (for now just a random distribution)
		const data = VEHICLE_MAP[name]
		const min = data.timerMin || 10, max = data.timerMax || 30
		const timerLength = Math.random()*(max - min) + min;

		// set the timer
		this.timers[name] = { 'val': timerLength, 'maxVal': timerLength, 'overtime': false }
		this.iconList[name].bar.displayWidth = 0;

		this.updateIconList();
	},

	goIntoOvertime: function(name) {
		var icon = this.iconList[name]
		var tm = this.timers[name]

		// TO DO: Change visuals (flip to a different progress bar frame with checkmarks?)

		// play simple alarm bell sound
		this.sound.play('alarm_1');
		
		// show upgrade button underneath (if this type can still be upgraded)
		if(!icon.upgraded && this.canUpgrade()) {
			icon.upgradeButton.setVisible(true);
		}

		const maxOvertime = 10;
		
		tm.val = maxOvertime
		tm.maxVal = maxOvertime
		tm.overtime = true;

		icon.defaultScale = icon.scaleX;

		var fromScale = icon.scaleX*0.9;
		var wantedScale = icon.scaleX*1.1;

		tm.animTween = this.tweens.add({
		    targets: icon,
		    alpha: { from: 0.5, to: 1 },
		    scaleX: { from: fromScale, to: wantedScale },
		    scaleY: { from: fromScale, to: wantedScale },
		    ease: 'Linear',       // 'Cubic', 'Elastic', 'Bounce', 'Back'
		    duration: 500,
		    repeat: -1,
		    yoyo: true
		});

		//icon.bar.setFrame(1);
	},

	stopTimer: function(name, success) {
		// can't stop a non-existent or active timer!
		var tm = this.timers[name];
		var icon = this.iconList[name];

		if(tm == null || !tm.overtime) {
			return;
		}

		if(success) {
			// nothing special
			// TO DO: play sound of coins clinking/points being added?
		} else {
			this.updateScore(-3);
			
			// play error sound
			this.sound.play('timer_fail_1');
		}

		// remove tween and reset to default scaling
		tm.animTween.remove();					
		icon.setScale(icon.defaultScale);

		this.timers[name] = null;
		this.updateIconList();
	},

	canUpgrade: function() {
		if(!this.upgradesAreInTheGame) {
			return false;
		}

		return this.score >= this.upgradeCost;
	},

	upgradeVehicle: function(name) {
		// can't upgrade if: 
		// 1) no active timer of this type
		// 2) not enough points
		// 3) already upgraded
		if(this.timers[name] == null) {
			return;
		}

		if(!this.canUpgrade()) {
			return;
		}

		var icon = this.iconList[name];
		if(icon.upgraded) {
			return;
		}

		// let's go!
		this.sound.play('upgrade_1');

		// switch icon for new one (both by name, frame and value)
		icon.upgraded = true;
		icon.setFrame(icon.frame.name + 4);

		const newName = this.convertFrameToVehicle(icon.frame.name);
		
		icon.myName = newName;
		icon.upgradeButton.myName = newName;

		// also update/stop the timer
		this.stopTimer(name, true);

		this.iconList[name] = null;
		this.iconList[newName] = icon;

		// subtract upgrade costs from score
		this.updateScore(-this.upgradeCost);
	},

	resetGoodTimer: function() {
		if(this.activeGood == null) {
			this.goodTimer = Math.random() * (this.cfg.maxGoodTimer - this.cfg.minGoodTimer) + this.cfg.minGoodTimer;
		} else {
			this.goodTimer = this.cfg.goodRunoutTime;
		}
		
		this.maxGoodTimer = this.goodTimer;
	},

	getRandomCity: function() {
		return this.cityNames[Math.floor(Math.random() * this.cityNames.length)];
	},

	getRandomGood: function() {
		const rand = Math.random()
		var sum = 0
		for(name in GOODS) {
			sum += (GOODS[name].prob / this.totalGoodProbability)

			if(sum >= rand) {
				return name;
			}
		}
	},

	addGood: function() {
		// play the overall announcement sound!
		this.sound.play('announcement_1');

		for(elem in this.goodWindow) {
			this.goodWindow[elem].setVisible(true);
		}

		// Grab random good and city
		var randGood = this.getRandomGood();
		var randCity = this.getRandomCity();

		this.goodWindow.good_sprite.setFrame( GOODS[randGood].frame )
		this.goodWindow.text.setText('[color=brown][b]New Good![/b][/color] [i]' + randCity + '[/i] receives ')

		this.activeGood = true
		this.resetGoodTimer();

		

		// (TO DO: Question => should I only reset the timer when the message is clicked away? Otherwise perhaps a bit too harsh)
	},

	removeGood: function(success) {
		if(!success) {
			this.updateScore(-1);
			this.sound.play('timer_fail_1');
		}

		// on click, always hide the good window again
		for(elem in this.goodWindow) {
			this.goodWindow[elem].setVisible(false);
		}

		// reset the timer
		this.activeGood = null
		this.resetGoodTimer();
	},

	resetEventTimer: function(nextPhase) {
		if(nextPhase == 'show') {

			// if playing without player ranks, just distribute randomly
			// (on average, one event per two minutes, give some extra margin on edges)
			if(this.cfg.playerRank == 0) {
				this.eventTimer = (this.cfg.playerCount*Math.random()*180 - 90) + 90;

			// if playing WITH player ranks, distribute evenly
			// (each event falls into some two minute interval only available to this player)
			} else {
				this.eventTimer = (this.cfg.playerRank - 1) * 180 + Math.random()*90;
			}

			this.maxEventTimer = this.eventTimer;

		} else if(nextPhase == 'hide') {
			var minLength = this.activeEvent.lengthMax || 30;
			var maxLength = this.activeEvent.lengthMax || 45;

			this.eventTimer = Math.random() * (maxLength - minLength) + minLength;
			this.maxEventTimer = this.eventTimer;
		}
	},

	getRandomEvent() {
		// first, grab the random event
		const rand = Math.random()
		var sum = 0
		var event = null
		for(name in EVENTS) {
			sum += (EVENTS[name].prob / this.totalEventProbability)

			if(sum >= rand) {
				event = EVENTS[name];
				break;
			}
		}

		this.activeEvent = event;

		// then replace any variables with their actual values
		// (first copy it, otherwise te permanently alter the original)
		var copyDesc = event.desc;
		var randomNumber = Math.floor(Math.random()*4)+2;

		copyDesc = copyDesc.replace("CITY", '[color=green][i]' + this.getRandomCity() + '[/i][/color]');
		copyDesc = copyDesc.replace("GOOD", '[color=brown][b]' + this.getRandomGood() + '[/b][/color]');
		copyDesc = copyDesc.replace("NUMBER", '[color=gray]' + randomNumber + '[/color]');

		return copyDesc;
	},

	showEvent: function() {
		var randEvent = this.getRandomEvent();
		this.eventWindow.text.setText(randEvent)

		for(elem in this.eventWindow) {
			this.eventWindow[elem].setVisible(true);
		}

		// play the overall announcement sound!
		this.sound.play('announcement_1');

		this.resetEventTimer('hide');
	},

	hideEvent: function() {
		for(elem in this.eventWindow) {
			this.eventWindow[elem].setVisible(false);
		}

		this.activeEvent = null;
		this.resetEventTimer('show');
	},

	startTimeout: function() {
		for(elem in this.waitingScreen) {
			this.waitingScreen[elem].setVisible(true);
		}

		this.waitingScreen.text.setText('Timeout!');
		this.waitingScreen.subText.setText("(click anywhere to end it)");

		this.gamePaused = true;
	},

	stopTimeout: function() {
		for(elem in this.waitingScreen) {
			this.waitingScreen[elem].setVisible(false);
		}

		this.previousTimeout = this.time.now;
		this.gamePaused = false;
	},

	update: function(time, delta) {
		if(this.gamePaused) { return; }

		const dt = delta / 1000.0;
		const timers = this.timers;

		// update all timers
		for(vehicleType in timers) {
			var tm = timers[vehicleType]
			var icon = this.iconList[vehicleType];

			if(tm == null || icon == null) { continue; }

			tm.val -= dt;

			const curVal = tm.val;
			var barColor, percentage;
			
			// Regularly, progress goes left to right, and colors with it
			if(!tm.overtime) {
				percentage = (tm.maxVal - tm.val) / tm.maxVal

				// NOTE: This is NOT a constructor, so don't put "new" keyword in front!
				barColor = Phaser.Display.Color.GetColor((1.0-percentage)*255, percentage*255, 0);

				if(curVal <= 0) {
					this.goIntoOvertime(vehicleType);
				}

			// In overtime, progress goes right to left, but stays green
			} else {
				percentage = tm.val / tm.maxVal
				barColor = color = 0x00FF00;

				if(curVal <= 0) {
					this.stopTimer(vehicleType, false);
				}
			}

			icon.bar.displayWidth = percentage * this.iconDisplaySize
			icon.bar.setTint(barColor)				
		}

		// update good placement timer
		// (if not active, show it => if active, remove it)
		if(this.cfg.goodsEnabled) {
			this.goodTimer -= dt;

			if(this.activeGood != null) {
				const percentage = this.goodTimer / this.maxGoodTimer;
				this.goodWindow.bar.displayWidth = percentage * this.goodWindow.bg_sprite.displayWidth
			}

			if(this.goodTimer <= 0) {
				if(this.activeGood == null) {
					this.addGood();
				} else {
					this.removeGood(false);
				}
			}
		}

		// update event timer
		// (resets automatically once timer ends; flips between two states)
		if(this.eventsAreInTheGame) {
			this.eventTimer -= dt;

			if(this.activeEvent != null) {
				const percentage = this.eventTimer / this.maxEventTimer;
				this.eventWindow.bar.displayWidth = percentage * this.eventWindow.bg_sprite.displayWidth
			}

			if(this.eventTimer <= 0) {
				if(this.activeEvent == null) {
					this.showEvent();
				} else {
					this.hideEvent();
				}
				
			}
		}

		// update global timer
		// this is added in SOLO mode only, as you must beat the game before the timer runs out
		if(this.globalTimerText != null) {
			this.globalTimerVal -= dt;
			this.globalTimerText.setText(this.convertSecondsToString(this.globalTimerVal));

			if(this.globalTimerVal <= 0) {
				this.globalTimerText.setColor('#FF0000');
				this.globalTimerText.setText(this.convertSecondsToString(0));
				
				this.sound.play('timer_fail_1');

				this.gamePaused = true;
			}
		}

		// check if timeout must be started (if enabled)
		if(this.cfg.timeout > 0) {
			if(time - this.previousTimeout > this.cfg.timeout*60*1000) {
				this.startTimeout();
			}
		}
	}
});

function startPhaserGame(gameConfig = {}) {
	document.getElementById('phaserGameContainer').innerHTML = '';

	//
	// does web audio exist in this browser?
	//
	var AudioContext = window.AudioContext // Default
	    || window.webkitAudioContext // Safari and old versions of Chrome
	    || false;

	var disableWebAudio;
	if(AudioContext) {
		disableWebAudio = false;
	} else {
		disableWebAudio = true;
	}

	// Checking for (mobile) Safari: (in phaser) this.sys.game.device.browser.mobilesafari
	// The JavaScript way:
	var ua = window.navigator.userAgent;
	var iOS = !!ua.match(/iPad/i) || !!ua.match(/iPhone/i);
	var webkit = !!ua.match(/WebKit/i);
	var iOSSafari = iOS && webkit && !ua.match(/CriOS/i);

	if(iOSSafari) {
		disableWebAudio = true;
	}

	var config = {
	    type: Phaser.AUTO,
	    scale: {
	        mode: Phaser.Scale.FIT,
	        parent: 'phaserGameContainer',
	        autoCenter: Phaser.Scale.CENTER_BOTH,
	        width: '100%',
	        height: '100%'
	    },

	    audio: {
		    disableWebAudio: disableWebAudio
		  },

	    backgroundColor: '#924314',
	    parent: 'phaserGameContainer',
	   	// scene: [MainGame, StateLoad],
	}

	window.GAME = new Phaser.Game(config); 

	GAME.scene.add('mainGame', MainGame, false, {});

	document.getElementById('fontPreloadHead').style.display = 'none';
	document.getElementById('fontPreloadBody').style.display = 'none';

	GAME.scene.start('mainGame', gameConfig);
}

startPhaserGame();