// global variable for code length (used both by generating board and actual game)
window.codeLength = 4;

// class constructor for special cells
function SpecialCell(category, name, explanation) {
	this.category = category
	this.name = name;
	this.explanation = explanation;
}

//
// this class holds the logic for randomly generating + drawing the board
//
const MainGame = new Phaser.Class({

    Extends: Phaser.Scene,

    initialize:
    function GameOver()
    {
        Phaser.Scene.call(this, { key: 'mainGame' });
    },

    preload: function() {
		this.load.crossOrigin = 'Anonymous';
		this.load.spritesheet('ingredients', 'gamesites/wondering-witches/IngredientSpritesheet.png', { frameWidth: 120, frameHeight: 120 });
		this.load.spritesheet('specialCells', 'gamesites/wondering-witches/SpecialCellSpritesheet.png', { frameWidth: 120, frameHeight: 120 });

		// IDEAS FOR SPECIAL TILES
		//  => OPTIONAL (Very complex/very hard): when you use this cell, you must tell the computer. It immediately scrambles the secret recipe, changing nothing OR changing exactly one thing.
		this.specialCellsUsed = [];
		this.specialCellsList = [
			// GOOD ONES
			new SpecialCell(0, 'Efficiency', 'You may put two separate ingredients on this cell'),
			new SpecialCell(0, 'Versatility', 'You may use this cell as a (single-cell) garden or cauldron'),
			new SpecialCell(0, 'Painter', 'When this cell is used, you may draw a line to divide or extend any garden/cauldron. When extending a cauldron, however, it MUST remain rectangular'),
			new SpecialCell(0, 'Guesser', 'When this cell is used, you may immediately test ANY potion you want for free! However, it must include the ingredient you just planted here'),

			// BAD ONES
			new SpecialCell(1, 'Low Ceiling', 'Whatever is in this cell may grow at MOST two steps'),
			new SpecialCell(1, 'Fertile Ground', 'Whenever you grow this cell, it must grow TWO steps at once'),
			new SpecialCell(1, 'Hard Ground', 'Whenever you plant something here, you must SKIP the next turn'),
			new SpecialCell(1, 'Black Magic', 'The soil is ruined&mdash;you simply cannot use this cell!'),
		];
    },

    create: function(config) {
    	// player count should have been passed in from the constructor
		this.playerCount = config.playerCount;
		this.difficulty = config.difficulty;

		this.numIngredients = 0;
		this.specialCellsEnabled = false;
		this.variableRecipe = false;
		codeLength = 4;

		switch(this.difficulty) {
			case 0:
			case 1:
				this.numIngredients = 6;
				break;

			case 2:
				this.numIngredients = 8;
				break;

			case 3:
				this.numIngredients = 8;
				this.variableRecipe = true;
				break;

			case 4:
				this.numIngredients = 8;
				this.specialCellsEnabled = true;
				this.variableRecipe = true;
				
				break;

			case 5:
				this.numIngredients = 10;
				this.specialCellsEnabled = true;
				this.variableRecipe = true;
				break;
		}

		// if variable recipe is enabled, well, vary the recipe!
		if(this.variableRecipe) {
			codeLength = 4 + Math.round(Math.random())*2;
		}

		// divide the paper into rectangles based on player count
		var paperSectionsLibrary = {
			'players-1': [[0,0,8,4]],
			'players-2': [[0,0,4,4], [4,0,4,4]],
			'players-3': [[0,0,5,2], [0,2,5,2], [5,0,3,4]],
			'default':   [[0,0,4,2], [4,0,4,2], [0,2,4,2], [4,2,4,2]],
			'players-5': [[0,0,3,2], [3,0,3,2], [0,2,3,2], [3,2,3,2], [6,0,2,4]],
		}

		// grab the right setup if it exists, otherwise go to the default setup (which is used in most cases)
		var tempSectionKey = 'players-' + this.playerCount;
		this.paperSections = [];
		if(typeof(paperSectionsLibrary[tempSectionKey]) == 'undefined') {
			this.paperSections = paperSectionsLibrary['default'];
		} else {
			this.paperSections = paperSectionsLibrary[tempSectionKey];
		}

		// Initialize some variables/properties for rendering
		this.xLines = 8;
		this.yLines = 4;

		this.fullWidth = 297*3;
		this.fullHeight = 210*3;

		this.lineWidth = 3;

		this.rectWidth = (this.fullWidth/this.xLines)
		this.rectHeight = (this.fullHeight/this.yLines)
		this.pageMargin = this.rectHeight;

		// Determine which section will have the required cell 
		// (the one where you must draw/note any status effects that players have)
		this.requiredCell = null;
		this.maxSpecialCells = 8;

		// Retry filling the board until we have a valid one
		do {
			this.generateGameBoard();
		} while(this.cauldronDistribution.length > 0 && this.cauldronCellsFilled <= 28);
		
		// visualize everything we just created
		this.visualizeGame();

		// after a small time interval, replace this whole game with just a static image
		// (why the wait? the canvas needs to be drawn/dirtied and updated, otherwise we copy a black canvas)
		this.time.addEvent({
		    delay: 200,
		    callback: function() {
		        // spawn a new apple
		        var canv = document.getElementById('phaserContainer').firstChild.nextSibling;

				var img = new Image();
				img.src = canv.toDataURL();
				img.style.maxWidth = '100%';
				document.getElementById('phaserContainer').appendChild(img);

				// finally, destroy this whole game
				GAME.destroy(true);
		    },
		    loop: false
		})
	},

	generateGameBoard: function() {
		// Determine a cauldron distribution
		// Requirements:
		//  * 32 cauldron cells in total
		//  * Each player has at least one cauldron
		//  * There must be one cauldron of length "codeLength"
		var maxCauldron = [3,2];
		if(!this.variableRecipe) { maxCauldron = [2,2]; }
		
		var totalCauldronCells = 32 - maxCauldron[0]*maxCauldron[1];
		this.cauldronDistribution = [maxCauldron];
		while(totalCauldronCells > 0) {
			var tempSizeX = Math.floor(Math.random()*3)+1;
			var tempSizeY = Math.floor(Math.random()*3)+1;

			// prevent cauldrons greater than our budget allows
			// (scale down to an approximately correct number)
			if(tempSizeX*tempSizeY > totalCauldronCells) {
				tempSizeX = totalCauldronCells;
				tempSizeY = Math.round(totalCauldronCells*0.5);
			}

			// prevent cauldrons of 1 (or less)
			if(tempSizeX*tempSizeY <= 1) {
				tempSizeX = 2;
				tempSizeY = 1;
			}

			// prevent cauldrons greater than 6
			if(tempSizeX*tempSizeY > 6) {
				tempSizeX = 3;
				tempSizeY = 2;
			}
			
			// subtract from total
			totalCauldronCells -= tempSizeX*tempSizeY;

			// add to distribution
			this.cauldronDistribution.push([tempSizeX, tempSizeY]);
		}

		// Sort the distribution descending (so we place the largest cauldrons first)
		this.cauldronDistribution.sort(function(a, b){ return b[0]*b[1] - a[0]*a[1] });

		// Create array of players + their own sections
		var playerArray = [];
		this.sections = [];
		for(var i = 0; i < this.paperSections.length; i++) {
			playerArray[i] = i;
			var s = this.paperSections[i];

			this.sections[i] = [];
			this.sections[i][0] = { 
				'rect': s,
				'fullRect': new Phaser.Geom.Rectangle(s[0]*this.rectWidth, s[1]*this.rectHeight, s[2]*this.rectWidth, s[3]*this.rectHeight),
				'cauldrons': [],
				'spaceLeft': s[2]*s[3],
			}

			this.sections[i][1] = {
				'rect': [(this.xLines - s[0] - s[2]), s[1], s[2], s[3]],
				'fullRect': new Phaser.Geom.Rectangle((this.xLines - s[0] - s[2])*this.rectWidth, s[1]*this.rectHeight, s[2]*this.rectWidth, s[3]*this.rectHeight),
				'cauldrons': [],
				'spaceLeft': s[2]*s[3],
			}
		}
		playerArray = shuffle(playerArray);

		// this variable keeps track of how many cauldron cells were actually filled
		// if this number is too low, we retry generation
		this.cauldronCellsFilled = 0;

		// Go through players randomly, trying to place any cauldron
		var curPlayerInd = 0;
		var turnsWithoutResult = 0;
		var pageToTryOut = 0;
		while(this.cauldronDistribution.length > 0 && turnsWithoutResult <= 100) {
			// grab current player
			var curPlayer = playerArray[curPlayerInd];

			// try to fit a cauldron there
			var result = this.fitCauldron(pageToTryOut, curPlayer);

			// keep track of how many subsequent turns were without result;
			// this ensures we never get an infinite loop
			if(!result) {
				turnsWithoutResult++;
			} else {
				turnsWithoutResult = 0;
				pageToTryOut = (pageToTryOut + 1) % 2;
			}

			// increase index; if we have to loop, shuffle again and loop
			curPlayerInd++;
			if(curPlayerInd >= playerArray.length) {
				playerArray = shuffle(playerArray);
				curPlayerInd = 0;
			}
		}

		// oh no, we failed!
		if(this.cauldronDistribution.length > 0 && this.cauldronCellsFilled <= 28) {
			return false;
		}

		// now go through all sections and fill them
		this.cauldrons = [];
		this.gardens = [];
		this.ingredients = [];
		this.specialCells = [];
		for(var page = 0; page < 2; page++) {
			for(var i = 0; i < this.paperSections.length; i++) {
				this.fillSection(page, i, this.paperSections[i]);
			}
		}
	},

	fitCauldron: function(page, playerNum) {
		// grab our section
		var s = this.sections[playerNum][page];
		var baseY = page*(this.yLines+1); // don't forget height difference from pages

		// go through cauldron distribution and find one that COULD fit in the space we have left
		var c = null;
		var cInd = -1;
		for(var i = 0; i < this.cauldronDistribution.length; i++) {
			var val = this.cauldronDistribution[i];
			// there must be space in SECTION and space left in TOTAL, after placing this cauldron
			// (otherwise one player might be stuck with ONLY cauldrons)
			if(val[0]*val[1] <= s.spaceLeft && (s.spaceLeft + this.sections[playerNum][(page+1)%2].spaceLeft) > val[0]*val[1]) {
				// and the cauldron may not exceed section boundaries of course
				if(val[0] <= s.rect[2] && val[1] <= s.rect[3]) {
					cInd = i;
					c = val;
					break;
				}
			}
		}

		// if nothing fits in our space, just return
		if(c == null) {
			return false;
		}

		// try it in both rotations (normal and flipped)
		for(var i = 0; i < 2; i++) {
			// flip it!
			if(i == 1) {
				var tempVal = val[0];
				val[0] = val[1];
				val[1] = tempVal;
			}

			// try it randomly on all possible positions (max 100 tries)
			var tryX, tryY;
			var notAllowed = true;
			var rectB;
			var tries = 0;
			do {
				tryX = Math.floor(Math.random()*(s.rect[2]-val[0]+1)) + s.rect[0];
				tryY = Math.floor(Math.random()*(s.rect[3]-val[1]+1)) + s.rect[1] + baseY;

				rectB = new Phaser.Geom.Rectangle(tryX*this.rectWidth, tryY*this.rectHeight, val[0]*this.rectWidth, val[1]*this.rectHeight);

				notAllowed = false;
				for(var c = 0; c < s.cauldrons.length; c++) {
					var rectA = s.cauldrons[c];
					if(Phaser.Geom.Rectangle.Overlaps(rectA, rectB)) {
						notAllowed = true;
						break;
					}
				}

				tries++;
			} while(notAllowed && tries <= 100);

			// if we found a valid cauldron, add it to the list
			// and remove it from the distribution
			if(tries <= 100) {
				s.cauldrons.push(rectB);
				s.spaceLeft -= val[0]*val[1];

				this.cauldronCellsFilled += val[0]*val[1];

				this.cauldronDistribution.splice(cInd,1);
				return true;
			}

			// otherwise, we can try the other rotation, and if nothing works out we just return emptyhanded
		}

		return false;

	},

	// @parameter "page" => the page (0 or 1; front or back) this section is on
	// @paramater "num" => number of the section ( = player number)
	// @parameter "rect" => array (length 4) with values (x0, y0, width, height) in _cells_
	fillSection: function(page, num, rect) {
		// determine the initial position
		// (we need to take into account y-position on second page, AND we need to flip the second page on the X-axis)
		var x0 = rect[0], y0 = rect[1] + page*(this.yLines+1);
		if(page%2 == 1) { x0 = this.xLines - x0 - rect[2]; }

		// determine maximum size cauldron we could place here
		var maxSizeX = rect[2], maxSizeY = rect[3]

		// copy cauldrons we created earlier
		var s = this.sections[num][page];
		for(var c = 0; c < s.cauldrons.length; c++) {
			this.cauldrons.push(s.cauldrons[c]);
		}

		//
		// fill the rest of the space with random gardens
		//

		// create empty "board" (2D array) for this section,
		// IGNORING the rectangles that are within our cauldron
		var section = [];
		var emptySpaces = 0;
		var possibleIngredientSpaces = [];
		var possibleCauldronSpaces = [];
		for(var cellX = 0; cellX < maxSizeX; cellX++) {
			section[cellX] = [];
			for(var cellY = 0; cellY < maxSizeY; cellY++) {
				
				// this checks all cauldrons to see what they are overlapping
				var overlappingRectangle = false;
				var cauldronSize = [0,0];
				var rectB = new Phaser.Geom.Rectangle((x0+cellX)*this.rectWidth, (y0+cellY)*this.rectHeight, this.rectWidth, this.rectHeight);
				for(var c = 0; c < s.cauldrons.length; c++) {
					var rectA = s.cauldrons[c];
					if(Phaser.Geom.Rectangle.Overlaps(rectA, rectB)) {
						overlappingRectangle = true;

						cauldronSize[0] = Math.round(rectA.width / this.rectWidth);
						cauldronSize[1] = Math.round(rectA.height / this.rectHeight);
						break;
					}
				}

				// if this cell is within a cauldron, ignore it
				if(overlappingRectangle) {
					section[cellX][cellY] = false;

					// only allow placement of ingredients in cauldrons that are NOT vital/essential 
					// (aka not equal to code length)
					if(cauldronSize[0]*cauldronSize[1] < codeLength) {
						possibleCauldronSpaces.push([x0 + cellX, y0 + cellY]);
					}

				// otherwise, add it
				} else {
					emptySpaces++;
					section[cellX][cellY] = true;
					possibleIngredientSpaces.push([x0 + cellX, y0 + cellY]);
				}
			}
		}

		//
		// at first possibility, add the required cell!
		// (for writing down player info and notes to remember)
		//
		if(this.requiredCell == null) {
			if(possibleIngredientSpaces.length > 0) {
				var randCell = possibleIngredientSpaces.splice(Math.floor(Math.random() * possibleIngredientSpaces.length), 1)[0];
				emptySpaces--;
				section[randCell[0]-x0][randCell[1]-y0] = false;

				this.requiredCell = [randCell[0], randCell[1]];
			} 
		}

		//
		// give each player a random starting ingredient
		// 50% chance it's in a garden, 50% chance in a cauldron
		//
		var possiblePositions = [];
		if(possibleIngredientSpaces.length > 0) {
			var randSpace = possibleIngredientSpaces.splice(Math.floor(Math.random() * possibleIngredientSpaces.length), 1)[0];
			possiblePositions.push(randSpace);
		}

		if(possibleCauldronSpaces.length > 0) {
			var randSpace = possibleCauldronSpaces.splice(Math.floor(Math.random() * possibleCauldronSpaces.length), 1)[0];
			possiblePositions.push(randSpace);
		}

		var randSpace = shuffle(possiblePositions)[0];
		var randIngredient = Math.floor(Math.random()*this.numIngredients);
		var insideGarden = section[randSpace[0]-x0][randSpace[1]-y0];
		this.ingredients.push({ 'pos': randSpace, 'type': randIngredient, 'insideGarden': insideGarden });

		//
		// if special cells are enabled, place some randomly
		// on a regular board, there should be ~32 open spaces, and we want ~6 special cells => probability is (6/32)
		//
		if(this.specialCellsEnabled) {
			for(var i = 0; i < possibleIngredientSpaces.length; i++) {
				// keep a maximum so we're NEVER creating a completely impossible/overwhelming game
				if(this.specialCells.length >= this.maxSpecialCells) {
					continue;
				}

				// otherwise, just throw a uniformly random dice and place something if it hits
				if(Math.random() <= (6.0/32)) {
					// slightly favor GOOD cells 75% over 25% BAD cells
					// (how? with 75% chance, whenever we encounter a bad cell, we keep looking)
					var randSpecialCell;
					var randSpecialCellIndex;
					do {
						randSpecialCellIndex = Math.floor(Math.random() * this.specialCellsList.length);
						randSpecialCell = this.specialCellsList[randSpecialCellIndex];
					} while(randSpecialCell.type == 1 && Math.random() <= 0.75);

					// remember we used this cell (but don't remember that more than once)
					if(!this.specialCellsUsed.includes(randSpecialCellIndex)) {
						this.specialCellsUsed.push(randSpecialCellIndex);
					}

					var randSpace = possibleIngredientSpaces[i];
					this.specialCells.push({ 'pos': randSpace, 'type': randSpecialCellIndex });
				}
			}
		}

		// go through all extra cells
		while(emptySpaces > 0) {
			// find a random place (that still exists)
			var gardenX, gardenY;
			do {
				gardenX = Math.floor(Math.random()*maxSizeX);
				gardenY = Math.floor(Math.random()*maxSizeY);
			} while(!section[gardenX][gardenY]);

			// start a garden here
			var newGarden = [ [gardenX + x0, gardenY + y0] ];
			section[gardenX][gardenY] = false;

			// now we simply go through neighbours (again and again) until we decide to stop (we're large enough) or we must stop (nothing to explore anymore)
			var cellsToCheck = [ [gardenX, gardenY] ];

			// check the neighbours (in a random order)
			var terminateLoop = false;
			while(!terminateLoop) {
				// grab the first cell on the list
				var c = cellsToCheck.splice(0,1)[0];

				emptySpaces--;

				// check all the neighbours (in a random order)
				var dirs = [[1,0], [0,1], [-1,0], [0,-1]];
				dirs = shuffle(dirs);
				for(var d = 0; d < 4; d++) {
					var tempX = c[0] + dirs[d][0], tempY = c[1] + dirs[d][1];

					// if out of bounds, ignore
					if(tempX < 0 || tempX >= maxSizeX || tempY < 0 || tempY >= maxSizeY) { continue; }

					// if non-existent, ignore
					if(!section[tempX][tempY]) { continue; }

					// now check probability: the larger we get, the less likely we are to grow
					var probCutoff = 1.0 / (0.5*newGarden.length);
					if(Math.random() > probCutoff) { continue; }

					//
					// we will grow!
					//

					// add this cell to the garden
					newGarden.push([tempX + x0, tempY + y0]);

					// and plan a check
					cellsToCheck.push([tempX, tempY]);

					// and remember we lost a space
					section[tempX][tempY] = false;
				}

				// terminate if there's nothing more to check
				terminateLoop = (cellsToCheck.length <= 0);
			}

			// add the final garden to the list
			this.gardens.push(newGarden);
		}

	},

    visualizeGame: function() {
    	var graphics = this.add.graphics();

    	// Create two page backgrounds
    	var textPos = [this.fullHeight + 32, this.fullHeight+this.pageMargin - 32];
    	var textStrings = ['Front', 'Back']
    	for(var page = 0; page < 2; page++) {
    		graphics.fillStyle(0xFFFFFF, 1.0);
    		graphics.fillRectShape( new Phaser.Geom.Rectangle(0, page*(this.fullHeight+this.pageMargin), this.fullWidth, this.fullHeight) );

    		var txtConfig = { fontFamily: 'Mali', fontSize: 16, color: '#FFFFFF' }
			var txt = this.add.text(this.fullWidth*0.5, textPos[page], textStrings[page], txtConfig);
			txt.setOrigin(0.5, 0.5);
    	}

		//
    	// Draw cauldrons
    	// (cauldrons are a very faint red, with a strong black outline)
    	//
    	for(var c = 0; c < this.cauldrons.length; c++) {
    		var rect = this.cauldrons[c];
			graphics.fillStyle(0xFFEEEE, 1.0);
			graphics.fillRectShape(rect);

			// add text about cauldron
			var txtConfig = { fontFamily: 'Mali', fontSize: 12, color: 0x111111 }
    		var markerMargin = this.lineWidth*2 + this.lineWidth;
			var txt = this.add.text(rect.x + markerMargin, rect.y + markerMargin, 'Cauldron', txtConfig);

			// move stroke a bit inwards
			var centerX = rect.x + 0.5*rect.width, centerY = rect.y + 0.5*rect.height;
			rect.setSize(rect.width - this.lineWidth, rect.height - this.lineWidth);
			Phaser.Geom.Rectangle.CenterOn(rect, centerX, centerY);
			graphics.lineStyle(this.lineWidth*2, 0x000000, 1.0);
			graphics.strokeRectShape(rect);
    	}

    	//
    	// Draw gardens
    	//
    	var gardenColors = [0x99FF99, 0x99EE99, 0x99DD99, 0x99CC99, 0x99BB99, 0x99AA99];
    	var gardenLines = [];
    	for(var g = 0; g < this.gardens.length; g++) {
    		var gard = this.gardens[g];

    		var bestMarkerCell = [1000,1000];

    		// draw each cell in the garden
    		for(var i = 0; i < gard.length; i++) {
    			var tempX = gard[i][0];
    			var tempY = gard[i][1];

    			var rect = new Phaser.Geom.Rectangle(tempX*this.rectWidth, tempY*this.rectHeight, this.rectWidth, this.rectHeight);
    			graphics.fillStyle(gardenColors[g % gardenColors.length], 1.0);
				graphics.fillRectShape(rect);

				// determine the "best marker cell": the one that is most to the top (left)
				if(tempX < bestMarkerCell[0] || (tempX == bestMarkerCell[0] && tempY < bestMarkerCell[1])) {
					bestMarkerCell = [tempX, tempY];
				}

				// also check, for each cell, if it should have a border
				// check all neighbours; if the neighbouring cell is NOT in the garden (for whatever reason), draw a border line
				var dirs = [[1,0], [0,1], [-1,0], [0,-1]];
				var myCenter = [(tempX+0.5)*this.rectWidth, (tempY+0.5)*this.rectHeight];
				var dirLines = [[1,-1,1,1], [1,1,-1,1], [-1,1,-1,-1], [-1,-1,1,-1]];
				for(var d = 0; d < 4; d++) {
					var nbX = tempX + dirs[d][0], nbY = tempY + dirs[d][1];

					var foundCell = false;
					for(var j = 0; j < gard.length; j++) {
						if(i == j) { continue; }

						if(gard[j][0] == nbX && gard[j][1] == nbY) {
							foundCell = true;
							break;
						}
					}

					// if there was NO cell from the same garden on this side, draw a line
					if(!foundCell) {
						var dl = dirLines[d]
						var line = new Phaser.Geom.Line(myCenter[0] + 0.5*dl[0]*this.rectWidth, myCenter[1] + 0.5*dl[1]*this.rectHeight, 
							                            myCenter[0] + 0.5*dl[2]*this.rectWidth, myCenter[1] + 0.5*dl[3]*this.rectHeight);
						gardenLines.push(line);
					}
				}
    		}

    		// create marker
    		var txtConfig = { fontFamily: 'Mali', fontSize: 12, color: 0x111111 }
    		var markerMargin = this.lineWidth*2 + this.lineWidth;
			var txt = this.add.text(bestMarkerCell[0] * this.rectWidth + markerMargin, bestMarkerCell[1] * this.rectHeight + markerMargin, 'Garden', txtConfig);
			// txt.setOrigin(0.5, 0.5);

    		// graphics.lineStyle(this.lineWidth, 0x00FF00, 1.0);
			// graphics.strokeRectShape(this.board[x][y]);
    	}

    	// This STROKES the gardens
    	// (we already determined the border edges in the code above)
    	for(var l = 0; l < gardenLines.length; l++) {
    		graphics.lineStyle(this.lineWidth, 0x000000, 1.0);
			graphics.strokeLineShape(gardenLines[l]);
    	}
    	
    	//
    	// Draw ingredients
    	//
    	var spriteSize = this.rectWidth*0.9;
    	for(var i = 0; i < this.ingredients.length; i++) {
    		var pos = this.ingredients[i].pos;
    		var type = this.ingredients[i].type;
    		var insideGarden = this.ingredients[i].insideGarden;
    		var newIng = this.add.sprite((pos[0] + 0.5)*this.rectWidth, (pos[1] + 0.5)*this.rectHeight, 'ingredients');

    		newIng.displayWidth = spriteSize;
    		newIng.displayHeight = spriteSize;
    		newIng.setOrigin(0.5, 0.5);

    		newIng.setFrame(type);

    		// if inside a garden ...
    		if(insideGarden) {
    			// add a dot next to it, to signal it has grown once
    			var circ = new Phaser.Geom.Circle(newIng.x + 0.35*spriteSize, newIng.y, 0.05*spriteSize);

    			graphics.fillStyle(0x000000, 1.0);
				graphics.fillCircleShape(circ);
    		
    		// if inside a cauldron ...
    		} else {
    			// add a random number next to it
    			var someRandomNumber = Math.floor(Math.random()*4)+1;

    			var txtConfig = { fontFamily: 'Mali', fontSize: 36, color: 0x111111, align: 'center' }
				var txt = this.add.text(newIng.x + 0.35*spriteSize, newIng.y, someRandomNumber, txtConfig);
				txt.setOrigin(0.5, 0.5);
    		}
    	}

    	//
    	// Draw the reserved/required cell
    	//
    	var rqCell = this.requiredCell;
    	if(rqCell != null) {
	    	var margin = this.lineWidth*2;
	    	var txtConfig = { fontFamily: 'Mali', fontSize: 12, color: 0x111111, align: 'center' }
			var txt = this.add.text((rqCell[0] + 0.5) * this.rectWidth, (rqCell[1] + 0.5) * this.rectHeight, 'Use this space for writing notes to remember (such as which players are poisoned)', txtConfig);
			txt.setOrigin(0.5, 0.5);
			txt.setWordWrapWidth(this.rectWidth - margin, false);
		}

		//
		// Draw the special cells
		//
		for(var i = 0; i < this.specialCells.length; i++) {
			var pos = this.specialCells[i].pos;
    		var type = this.specialCells[i].type;
    		var newIng = this.add.sprite((pos[0] + 0.5)*this.rectWidth, (pos[1] + 0.5)*this.rectHeight, 'specialCells');

    		newIng.displayWidth = spriteSize;
    		newIng.displayHeight = spriteSize;
    		newIng.setOrigin(0.5, 0.5);

    		newIng.setFrame(type);
		}

		// also, add explanations for the cells underneath the board
		var cont = document.getElementById('specialCellContainer');
		for(var i = 0; i < this.specialCellsUsed.length; i++) {
			var tempInd = this.specialCellsUsed[i];
			var tempName = this.specialCellsList[tempInd].name;
			var tempExplanation = this.specialCellsList[tempInd].explanation;

			var newElem = '<div class="specialCellExplainer"><span><div class="specialCellSprite" style="background-position:' + (-120 * tempInd) + 'px;"></div></span>';
			newElem += '<span><strong>' + tempName + '</strong></span>';
			newElem += '<span>' + tempExplanation + '</span>';
			newElem += '</div>';
			cont.innerHTML += newElem;
		}


		//
    	// Draw grid lines + player areas
    	//
    	// Colors from:
    	// * https://graphicdesign.stackexchange.com/questions/3682/where-can-i-find-a-large-palette-set-of-contrasting-colors-for-coloring-many-d
    	// * https://sashat.me/2017/01/11/list-of-20-simple-distinct-colors/
    	//
    	var playerColors = [0x800000, 0x9A6324, 0x008080, 0x911EB4, 0x808088];
    	var playerColorsHex = ['#800000', '#9a6324', "#008080", "#911EB4", "#808088"];
    	var tinyLineWidth = Math.floor(0.5*this.lineWidth);
    	for(var page = 0; page < 2; page++) {
			var baseX = 0.5*this.fullWidth, baseY = page*(this.fullHeight+this.pageMargin);

			// => vertical
			for(var x = 0; x < this.xLines; x++) {
				var xPos = x*this.rectWidth;
				var l = new Phaser.Geom.Line(xPos, baseY, xPos, baseY+this.fullHeight);
				graphics.lineStyle(tinyLineWidth, 0x6666ff, 0.5);
				graphics.strokeLineShape(l);
			}

			// => horizontal
			for(var y = 0; y < this.yLines; y++) {
				var yPos = y*this.rectHeight + baseY;
				var l = new Phaser.Geom.Line(0, yPos, this.fullWidth, yPos);
				graphics.lineStyle(tinyLineWidth, 0x6666ff, 0.5);
				graphics.strokeLineShape(l);
			}

			// => player area
			// (just stroke the rectangle, then scale it slightly inwards for better visuals)
			// (also, place some text that shows which player is where)
			for(var i = 0; i < this.paperSections.length; i++) {
				var s = this.paperSections[i];
				var x = s[0]*this.rectWidth, y = s[1]*this.rectHeight+baseY, width = s[2]*this.rectWidth, height = s[3]*this.rectHeight
				if(page%2 == 1) { x = (this.xLines - s[0] - s[2])*this.rectWidth; }

				var rect = new Phaser.Geom.Rectangle(x, y, width, height);

				var centerX = (x+0.5*width), centerY = (y+0.5*height);
				var edgeOffset = this.lineWidth;
				rect.setSize(width - 2*edgeOffset, height - 2*edgeOffset);
				Phaser.Geom.Rectangle.CenterOn(rect, centerX, centerY);

				graphics.lineStyle(this.lineWidth*2, playerColors[i], 1.0);
				graphics.strokeRectShape(rect);

				// display text
				var myPlayers = (i+1);
				if(this.playerCount > 5 && (i+4) < this.playerCount) {
					myPlayers += ' and ' + (i+4+1);
				}

				// Phaser.Display.Color.IntegerToColor(colorInt)??
				var txtConfig = { fontFamily: 'Mali', fontSize: 16, color: playerColorsHex[i] }
				var txt = this.add.text(centerX, centerY, 'Player ' + myPlayers, txtConfig);
				txt.setOrigin(0.5, 0.5);

				// create rectangle behind player text
				var rectBehindText = txt.getBounds();
				rectBehindText.width += 20;
				rectBehindText.height += 20;
				Phaser.Geom.Rectangle.CenterOn(rectBehindText, txt.x, txt.y);

				graphics.fillStyle(0xFFFFFF, 1.0);
				graphics.fillRectShape(rectBehindText);
			}
		}
    }
});

function startPhaser(playerCount, difficulty) {
	//
	// this starts the Phaser game
	// (and sets all this random generation in motion)
	//
	var config = {
	    type: Phaser.CANVAS,
	    scale: {
	        mode: Phaser.Scale.FIT,
	        parent: 'phaserContainer',
	        autoCenter: Phaser.Scale.CENTER_BOTH,
	        width: 297*3,
	        height: 210*3*2 + 157.5
	    },
	    backgroundColor: '#4B2142',
	    parent: 'phaserContainer',
	    scene: [MainGame],
	}

	window.GAME = new Phaser.Game(config); 
	GAME.scene.start('mainGame', { 'playerCount': playerCount, 'difficulty': difficulty });

	// warning/prompt to prevent people from leaving accidentally
	window.onbeforeunload = function() { return "If you leave now, your current game will be deleted. Are you sure?"; };
}

// listen for clicks on the "generate board" button
document.getElementById('generateBoardBtn').addEventListener('click', function(ev) {
	// hide button and player counter
	document.getElementById('playerCountForm').style.display = 'none';
	ev.currentTarget.style.display = 'none';

	// grab player count + difficulty (input by user)
	var playerCount = parseInt( document.getElementById('playerCount').value );
	var difficulty = parseInt( document.getElementById('difficulty').value );

	// start phaser
	startPhaser(playerCount, difficulty);
});