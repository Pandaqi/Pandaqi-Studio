// shuffle function for randomizing a list
// the fastest and most reliable way I know to pick random events
function shuffle(a) {
    var j, x, i;
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
    return a;
}

// effect constructor
// categories: 0 = change cauldron, 1 = report results/clues, 2 = change players, 3 = change playing field
function Effect(category, name, explanation) {
	this.category = category
	this.name = name;
	this.explanation = explanation;
}

// this variable is used for checking (before starting a game) whether the generated puzzle is even SOLVABLE
var puzzleIsValid = false;

// these variables are input by the player
// (note: codeLength is global, already defined in previous script)
var playerCount = 2;
var difficulty = 0;
var effectsLevel = 0;

// these are determined by the puzzle/program
var curCauldron = [];
var curPuzzle = [];
var numIngredients = 10;
var variableRecipe = false;

var ingredientNames = ["Parsley", "Sage", "Chives", "Rosemary", "Oregano", "Mint", "Dill", "Basil", "Thyme", "Black Pepper"];

var numEffects = 5;
var allEffects = {};

allEffects['ChangeCauldron'] = [
	// CHANGE CAULDRON (these can be a great obstacle, or you can use these to your advantage)
	new Effect(0, "Cutoff", "When this ingredient is encountered, all ingredients after it aren't considered anymore."),
	new Effect(0, "Spicy", "Raises the number of the ingredient AFTER it by one. (Only during potion evaluation, not permanently.)"),
	new Effect(0, "Refreshing", "Lowers the number of the ingredient AFTER it by one. (Only during potion evaluation, not permanently.)"),
	new Effect(0, "Enthusiastic", "When the computer examines a potion, it SKIPS the ingredient after this one."),
	new Effect(0, "Cleaner", "Removes all effects from the ingredient AFTER itself. (Only during potion evaluation, not permanently.)"),
	new Effect(0, "Fertilizer", "Pretends the next overgrown/undergrown element is actually perfect. (It's not reported and not automatically counted as being wrong.)"),
];

allEffects['Investigative'] = [
	// INVESTIGATIVE
	new Effect(1, "Detective", "Returns the number of a random ingredient in the same cauldron"),
	new Effect(1, "Liar", "Returns a random number that is NOT within this cauldron"),
	new Effect(1, "Inspector", "Returns the number of ingredients that have one or multiple effects"),
	new Effect(1, "General", "Returns the total number of effects active within the cauldron"),
	new Effect(1, "Pessimist", "Returns how many ingredients in this cauldron are in the WRONG order. (The ingredient before them is not exactly one below their number.)"),
	new Effect(1, "Optimist", "Returns how many ingredients in this cauldron are in the RIGHT order. (The ingredient before them is exactly one below their number.)"),
	new Effect(1, "Calculator", "Returns the sum of all secret numbers"),
	new Effect(1, "Joker", "Disguises itself as one of the other investigative effects (see the rulebook). Every time you test it, it executes a different effect and gives you the results."),
	new Effect(1, "Revealer", "Returns how many DECOYS are within this cauldron"),
	new Effect(1, "Blessing", "Returns how many GOOD ingredients are within this cauldron"),


	new Effect(1, "Scientist", "Returns YES if at least one ingredient in the cauldron has <em>more than one</em> effect, NO otherwise."),
	new Effect(1, "Hugger", "Returns YES if the ingredient before it has a number that's one higher/lower than its own, NO otherwise."),
	new Effect(1, "Crowdy", "Yells \"It's so crowded in here!\" if it's in a cauldron with at least three other ingredients"),
	//new Effect(1, "Winner", "This ingredient MUST be in a cauldron with the ingredient that has number 1"),
	//new Effect(1, "Loser", "This ingredient MUST be in a cauldron with the ingredient that has number 10"),
	new Effect(1, "Brothers", "This ingredient has a related ingredient (their brother). They MUST be in the same cauldron!"),
	new Effect(1, "Enemies", "This ingredient has a related ingredient (their enemy). They may NOT be in the same cauldron!"),

	new Effect(1, "Imposter", "Automatically given to imposter decoys, but can be given to regular ingredients as well. You receive the feedback \"An imposter was encountered\"."),
];

allEffects['ChangePlayers'] = [
	// CHANGE PLAYERS (handicap or special power)
	new Effect(2, "Poison", "You immediately become <em>poisoned</em>. (This changes nothing in-game, you simply lose if all players are poisoned.)"),
	new Effect(2, "Green Fingers", "You get the <em>green fingers</em> ability. Any time they grow a garden, they <em>may</em> grow it two steps."),
	new Effect(2, "Piggyback", "From now on, you must always take your action on the board of another player."),
	new Effect(2, "Allergies", "You become Allergic to all ingredients within this potion. You may not plant them or put them in your cauldron."),
	new Effect(2, "Distracted", "You become (easily) Distracted. From now on, your plants may only grow at MOST two steps."),
	new Effect(2, "Healer", "You become healed! You lose all player effects. If you have none, you may grant yourself one player effect (see rulebook)"),
	new Effect(2, "Genius", "You become a Genius! Any time a potion is tested, you may change ONE thing at the last minute (add an ingredient, change the number of seeds, ...)"),
];

allEffects['ChangeField'] = [
	// CHANGE PLAYING FIELD (modify cauldrons, ingredients, seeds, etc.)
	new Effect(3, "Drought", "A drought consumes the land! Immediately cross out one ingredient that is still growing. If there is no available ingredient, you immediately lose the game!"),
	new Effect(3, "Efficiency", "Choose any empty field and write a small '2' inside it. This cell can now hold two ingredients. (This field may be inside a cauldron or a garden.)"),
	new Effect(3, "Fire", "Oh no, a fire has started! Pick a cell, cross it out, and draw a fire icon in it. At the end of every round, the fire must spread to an adjacent cell, which has not been touched by fire yet."),
	new Effect(3, "Magic", "Change one thing on the board, ignoring all other rules in the game. For example, put out a fire, put any ingredient in a cauldron for free, heal a player effect, connect two separate gardens, ...")
];

// these effects are REALLY hard and difficult to decipher/use properly, which means they're only used on the highest difficulty
// (at that difficulty, they are mixed in with the rest)
allEffects['Complex'] = [
	new Effect(4, "Resetter", "Resets evaluation. The computer forgets everything and starts again from the NEXT ingredient."),
	new Effect(4, "Equalizer", "The secret number of the ingredient AFTER it becomes EQUAL to the number of effects that it has"),

	new Effect(4, "Student", "You become a <em>Student</em> of nature! You may plant any ingredients, even if they are not your <em>specialty</em>."),
	new Effect(4, "Spreader", "You gain the <em>Spreader</em> ability! You may plant ingredients in any garden (not just your own)."),

	new Effect(4, "Random", "When this ingredient is evaluated, it determines a random secret number on the spot"),

	new Effect(4, "Blender", "Its secret number is increased by the number of GOOD ingredients within the same cauldron"),
	new Effect(4, "Downer", "Its secret number is decreased by the number of DECOYS within the same cauldron"),

	new Effect(4, "Teamplayer", "The secret number of the ingredient BEFORE it is added to its own secret number"),
	new Effect(4, "Analyzer", "Reports the DISTANCE between its secret number and its location within the potion. (Example: if it has number 3, but it's at the first spot in the potion, then it returns 3-1=2."),

	new Effect(4, "Odd", "If there is an odd number of ingredients in the potion, it disables itself (temporarily): it becomes an ignore decoy and disables any effects it has't yet executed."), 
	new Effect(4, "Even", "If there is an even number of ingredients in the potion, it becomes happy and tells you what it is. If not, it becomes a random result, both to you and other effects."),
	new Effect(4, "Coward", "If this effect is in the first half of the cauldron, it moves itself to the LAST position in the cauldron"),
];

var effectExplanations = {}; // used during the game to quickly display an explanation for a tapped/clicked effect
var curEffectExplanationActive = null;

// removes ingredient with container "myCont" on the page
function removeIngredient(myCont) {
	// retrieve the ingredient number from the container ID
	// TO DO: This is a very hacky way of doing this---rewrite to something better?
	var myNum = myCont.id.substring(10, myCont.id.length);
	myNum = parseInt(myNum);

	// remove this ingredient from the page (visually)
	myCont.parentNode.removeChild(myCont);

	// move all ingredients after it down by a spot
	// by updating their attributes
	for(var i = (myNum+1); i < curCauldron.length; i++) {
		document.getElementById("ingredientSeeds" + i).id = "ingredientSeeds" + (i-1);
		document.getElementById("ingredient" + i).id = "ingredient" + (i-1);
	}

	// remove this ingredient from the cauldron (code)
	curCauldron.splice(myNum, 1);

	// if the cauldron is now empty, remove the "use potion"
	if(curCauldron.length <= 0) {
		document.getElementById('usePotionButton').style.display = 'none';
	}
}

// adds ingredient of type "myType" to the cauldron array
function addIngredient(myType) {
	// create new element
	var newElement = document.createElement('div');
	newElement.classList.add('oneIngredient');

	// remember our number
	var ingredientNum = curCauldron.length;
	newElement.id = 'ingredient' + ingredientNum;

	// add button for removing this ingredient
	var removalButton = document.createElement('button');
	removalButton.innerHTML = 'X';
	removalButton.myContainer = newElement
	removalButton.addEventListener('click', function(ev) {
		removeIngredient( ev.currentTarget.myContainer );
	});
	newElement.appendChild(removalButton);

	// display correct ingredient type
	var typeImage = document.createElement('span');
	typeImage.innerHTML += '<div class="ingSprite-small" style="background-position:' + (-60*myType) + 'px;"></div>';
	newElement.appendChild(typeImage);

	var typeText = document.createElement('span');
	typeText.innerHTML = ingredientNames[myType];
	typeText.classList.add('ingredientName-inCauldron');
	newElement.appendChild(typeText);

	var newSpan = document.createElement('span');
	newSpan.innerHTML = 'Seeds: ';

	// add interactive dropdown for number of seeds
	var newDropdown = document.createElement('select');
	newDropdown.id = "ingredientSeeds" + ingredientNum;

	// at most, an ingredient will have number 6 (as that is the maximum code length)
	var maxCodeLength = 6;
	if(!variableRecipe) {
		maxCodeLength = 4;
	}

	for(var i = 0; i < maxCodeLength; i++) {
		var newOption = document.createElement('option');
		newOption.value = (i+1);
		newOption.innerHTML = (i+1);
		newDropdown.appendChild(newOption);
	}

	newSpan.appendChild(newDropdown);
	newElement.appendChild(newSpan);

	// add it to the array (code)
	// COPY the number and any effects from the puzzle, as this makes the code much easier and cleaner
	var obj = { "myType": myType, "mySeeds": 0, "myNum": curPuzzle[myType].myNum, "effects": curPuzzle[myType].effects, "decoyStatus": curPuzzle[myType].decoyStatus };
	curCauldron.push(obj);

	// add it to the list (visually)
	document.getElementById('currentCauldron').appendChild(newElement);

	// make sure the "use potion" button is visible
	document.getElementById('usePotionButton').style.display = 'block';

	// remove the potionResult
	document.getElementById('potionResult').style.display = 'none';

	// scroll towards the elements we just added
	newElement.scrollIntoView();
}

function clearIngredients() {
	curCauldron = [];
	document.getElementById('currentCauldron').innerHTML = '';
	document.getElementById('usePotionButton').style.display = 'none';
}

// DISCARDED IDEAS
//
// These effects were replaced with decoys that to do exactly this:
//  => One that makes an ingredient always report undergrown
//  => One that makes an ingredient always report overgrown
//
// These became useless when I changed the game rules (the range of numbers isn't guaranteed):
//  => One that MUST be in a cauldron with the number 10
//  => One that MUST be in a cauldron with the number 1 
//
// Would be a nightmare to code, and is probably too powerful:
//  => One that turns a single "bad/decoy" ingredient into a good one

// What do effects need to do? In general, players want to know about: secret numbers, decoys, whether stuff has effects, and effects that change the cauldron (and thus the winning condition)
function checkEffect(cauldronIndex, effectName, obj, obscureName = false) {
	var feedbackText = '';
	var cSize = curCauldron.length;

	var feedbackValue = '';
	var singular = true;
	switch(effectName) {
		//
		// CHANGE CAULDRON
		//
		case 'Cutoff':
			obj.directEffects['Cutoff'] = true;
			feedbackValue = "The ingredient was cut off";
			break;

		case 'Spicy':
			if(cauldronIndex < (cSize - 1)) {
				curCauldron[(cauldronIndex+1)].myNum++; 
			}
			feedbackValue = "A spicy ingredient was encountered";
			break;

		case 'Refreshing':
			if(cauldronIndex < (cSize - 1)) {
				curCauldron[(cauldronIndex+1)].myNum--; 
			}
			feedbackValue = "A refreshing ingredient was encountered";
			break;

		case 'Enthusiastic':
			obj.directEffects['Enthusiastic'] = true;
			feedbackValue = "Enthusiastic skipped an ingredient";
			break;

		case 'Cleaner':
			if(cauldronIndex < (cSize - 1)) {
				curCauldron[(cauldronIndex+1)].effects = [];
			}
			feedbackValue = "A cleaning ingredient was encountered";
			break;

		case 'Fertilizer':
			obj.directEffects['Fertilizer'] = true;
			feedbackValue = "A fertilizer worked its magic";
			break;

		//
		// INVESTIGATIVE
		//
		case 'Imposter':
			feedbackValue = "An imposter was encountered";
			break;

		case 'Liar':
			// make list of all numbers
			var allNumbers = [];
			for(var i = 0; i < codeLength; i++) {
				allNumbers[i] = i;
			}

			// go through cauldron and REMOVE numbers that are present
			for(var i = 0; i < cSize; i++) {
				var findElem = allNumbers.indexOf(curCauldron[i].myNum);
				if(findElem > -1) {
					allNumbers.splice(findElem, 1);
				}
			}

			// now pick one randomly
			singular = false;
			if(allNumbers.length > 0) {
				var randNum = allNumbers[Math.floor(Math.random()*allNumbers.length)];
				feedbackValue = 'number ' + randNum;
			} else {
				feedbackValue = 'nothing to say';
			}
			break;

		case 'Detective':
			var randNum = curCauldron[Math.floor(Math.random() * cSize)].myNum;

			singular = false;
			feedbackValue = 'number ' + randNum;
			break;

		case 'General':
			var totalNumEffects = 0;
			for(var i = 0; i < cSize; i++) {
				totalNumEffects += curCauldron[i].effects.length;
			}

			singular = false;
			feedbackValue = totalNumEffects;
			break;

		case 'Inspector':
			var numWithEffects = 0;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].effects.length > 0) {
					numWithEffects++;
				}
			}

			singular = false;
			feedbackValue = numWithEffects;
			break;

		case 'Calculator':
			var sum = 0;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].myNum == -1) { continue; }
				sum += curCauldron[i].myNum;
			}

			singular = false;
			feedbackValue = sum;
			break;

		case 'Revealer':
			var numDecoys = 0;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].decoyStatus != -1) {
					numDecoys++;
				}
			}

			singular = false;
			feedbackValue = numDecoys;
			break;

		case 'Blessing':
			var numReal = 0;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].decoyStatus == -1) {
					numReal++;
				}
			}

			singular = false;
			feedbackValue = numReal;
			break;

		case 'Joker':
			// TO DO: Make this list longer/shorter?
			var investigativeEffects = ["Liar", "Detective", "General", "Inspector", "Calculator", "Revealer", "Blessing", "Hugger"];
			var randInv = investigativeEffects[Math.floor(Math.random()*investigativeEffects.length)];

			// check the effect
			// the fourth parameter ("true") tells the computer to hide the name of the effect, and give it back to us instead
			var tempFeedback = checkEffect(cauldronIndex, randInv, obj, true);

			singular = false;
			feedbackValue = tempFeedback;
			break;

		case 'Hugger':
			var myNum = curCauldron[cauldronIndex].myNum;
			var msg = 'NO';
			if(cauldronIndex > 0 && Math.abs(curCauldron[(cauldronIndex-1)].myNum - myNum) <= 1) {
				msg = 'YES';
			}
			
			singular = false;
			feedbackValue = msg;
			break;

		case 'Scientist':
			var msg = 'NO';
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].effects.length > 1) {
					msg = 'YES';
					break;
				}
			}

			singular = false;
			feedbackValue = msg;
			break;

		case 'Crowdy':
			singular = false;
			if(curCauldron.length >= 4) {
				feedbackValue = "\"It's so crowded in here!\"";
			}
			break;

		/*
		case 'Winner':
			// QUESTION: Add feedback?

			// otherwise, update wrongness
			var isWrong = true;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].myNum == 1) {
					isWrong = false;
					break;
				}
			}

			// if we're already wrong, don't even consider this
			if(obj.isWrong) { break; }
			obj.isWrong = isWrong;
			break;

		case 'Loser':
			// QUESTION: Add feedback?

			// otherwise, update wrongness
			var isWrong = true;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].myNum == 10) {
					isWrong = false;
					break;
				}
			}

			if(obj.isWrong) { break; }
			obj.isWrong = isWrong;
			break;
		*/

		case 'Brothers':
			// QUESTION: Add feedback?

			var isWrong = true;
			for(var i = 0; i < cSize; i++) {
				if(i == cauldronIndex) { continue; } // skip ourselves
				if(curCauldron[i].effects.includes("Brothers")) {
					isWrong = false;
					break;
				}
			}

			if(obj.isWrong) { break; }
			obj.isWrong = isWrong;
			break;

		case 'Enemies':
			// QUESTION: Add feedback?

			var isWrong = false;
			for(var i = 0; i < cSize; i++) {
				if(i == cauldronIndex) { continue; } // skip ourselves
				if(curCauldron[i].effects.includes("Enemies")) {
					isWrong = true;
					break;
				}
			}

			if(obj.isWrong) { break; }
			obj.isWrong = isWrong;
			break;

		case 'Optimist':
			var numCorrect = 0;
			for(var i = 1; i < cSize; i++) {
				if(curCauldron[i].myNum == curCauldron[(i-1)].myNum + 1) {
					numCorrect++;
				}
			}

			singular = false;
			feedbackValue = " are correct";
			break;

		case 'Pessimist':
			var numIncorrect = 0;
			for(var i = 1; i < cSize; i++) {
				if(curCauldron[i].myNum != curCauldron[(i-1)].myNum + 1) {
					numIncorrect++;
				}
			}
			
			singular = false;
			feedbackValue = numIncorrect + " are incorrect";
			break;


		//
		// CHANGE PLAYERS
		//
		case 'Poison':
			feedbackValue = "You are now <em>poisoned</em>!";
			break;

		case 'Green Fingers':
			feedbackValue = "You get the ability <em>Green Fingers</em>!";
			break;

		case 'Piggyback':
			feedbackValue = 'Oh no, you have become a <em>Piggyback</em>!';
			break;

		case 'Allergies':
			feedbackValue = 'Too bad, you just got <em>Allergies</em>!';
			break;

		case 'Distracted':
			feedbackValue = 'You get the handicap <em>Distracted</em>!';
			break;

		case 'Healer':
			feedbackValue = 'You were <em>healed</em>! Well done!';
			break;

		case 'Genius':
			feedbackValue = 'You have become a <em>Genius</em>';
			break;

		//
		// CHANGE PLAYING FIELD
		//
		case 'Drought':
			feedbackValue = "Oh no! A drought occured!";
			break;

		case 'Efficiency':
			feedbackValue = "Yes! One cell may now become more efficient!";
			break;

		case 'Fire':
			feedbackValue = 'Oh no! A fire has started!';
			break;

		case 'Magic':
			feedbackValue = 'It\'s a kind of <strong>magic</strong>! You may immediately change one thing, anything, on the board.';
			break;

		//
		// COMPLEX EFFECTS
		//
		case 'Resetter':
			obj.directEffects['Resetter'] = true;
			feedbackValue = 'A reset occured!';
			break;

		case 'Equalizer':
			var nextNum = cauldronIndex + 1;
			if(nextNum < curCauldron.length) {
				curCauldron[nextNum].myNum = curCauldron[nextNum].effects.length;
			}

			feedbackValue = 'An equalizer was encountered';
			break;

		case 'Student':
			feedbackValue = "You become a <em>Student</em> of nature!"
			break;

		case 'Spreader':
			feedbackValue = 'You gain the <em>Spreader</em> ability!';
			break;

		case 'Random':
			curCauldron[cauldronIndex].myNum = Math.floor(Math.random()*codeLength)+1;
			feedbackValue = 'An ingredient did something Random ...';
			break;

		case 'Blender':
			var numGood = 0;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].decoyStatus == -1) {
					numGood++;
				}
			}
			curCauldron[cauldronIndex].myNum += numGood;
			feedbackValue = 'Ingredients were thrown in the Blender';
			break;

		case 'Downer':
			var numDecoys = 0;
			for(var i = 0; i < cSize; i++) {
				if(curCauldron[i].decoyStatus >= 0) {
					numDecoys++;
				}
			}
			curCauldron[cauldronIndex].myNum -= numDecoys;
			feedbackValue = 'A Downer was encountered';
			break;

		case 'Teamplayer':
			if(cauldronIndex > 0) {
				curCauldron[cauldronIndex].myNum += curCauldron[cauldronIndex-1].myNum;
			}
			feedbackValue = 'A teamplayer was present';

		case 'Analyzer':
			singular = false;
			if(curCauldron[cauldronIndex].myNum == -1) {
				feedbackValue = "no distance possible ...";
			} else {
				feedbackValue = 'distance was ' + Math.abs(curCauldron[cauldronIndex].myNum - (cauldronIndex+1));
			}
			break;

		case 'Odd':
			if(cSize % 2 == 1) {
				curCauldron[cauldronIndex].decoyStatus == 0;
				curCauldron[cauldronIndex].myNum = -1;
				curCauldron[cauldronIndex].effects = [];
			}
			feedbackValue = 'An odd ingredient was encountered';
			break;

		case 'Even':
			singular = false;
			if(cSize % 2 == 0) {
				if(curCauldron[cauldronIndex].decoyStatus == -1) {
					feedbackValue = "I'm number " + curCauldron[cauldronIndex].myNum;
				} else {
					feedbackValue = "I'm a decoy";
				}	
			} else {
				var randNum = Math.floor(Math.random()*codeLength)+1;
				curCauldron[cauldronIndex].myNum = randNum;
				feedbackValue = "I'm number " + randNum;
			}
			break;

		case 'Coward':
			if(cauldronIndex <= Math.floor(cSize*0.5)) {
				// splice this element from the cauldron
				var us = curCauldron.splice(cauldronIndex, 1)[0];

				// add it back at the end
				// (this keeps the cauldron size and content constant, only in a different order)
				curCauldron.push(us);

				// remember to execute some direct consequences in the loop
				obj.directEffects['Coward'] = true;
			}
			feedbackValue = 'One ingredient was a Coward.';
			break;
	}

	if(feedbackValue != '') {
		if(singular) {
			feedbackText = generateFeedbackSingular(feedbackValue);
		} else {
			feedbackText = generateFeedback(effectName, feedbackValue);
		}
	}

	if(obscureName) {
		return feedbackValue;
	} else {
		if(feedbackText.length > 0) {
			obj.feedbackText.push(feedbackText);
		}
	}

	
}

function generateFeedback(effectName, message) {
	return '<p><strong>' + effectName + '</strong> says <strong>' + message + '</strong></p>';
}

function generateFeedbackSingular(message) {
	return '<p>' + message + '</p>';
}

function checkIngredient(cauldronIndex) {
	var ing = curCauldron[cauldronIndex];
	var obj = { 
		"isWrong": false, 
		"feedbackText": [], 
		"directEffects": {
			"Cutoff": false,
			"Enthusiastic": false,
			"Fertilizer": false,
			'Resetter': false,
			'Coward': false,
		} 
	};

	// if the number is greater than 0, check the ordering
	// ordering is correct if two ingredients are in direct sequence (e.g. 4 => 5)
	if(cauldronIndex > 0) {
		obj.isWrong = !(curCauldron[(cauldronIndex-1)].myNum == (ing.myNum - 1));
	}

	// now check all the effects individually
	var effects = ing.effects;
	for(var i = 0; i < effects.length; i++) {
		checkEffect(cauldronIndex, effects[i], obj);
	}

	return obj;
}

function usePotion(fixedInput = null) {
	var cSize = curCauldron.length;

	// if we have a fixed input (used during puzzle generation/testing), use that to create a cauldron
	if(fixedInput != null) {
		curCauldron = [];
		for(var i = 0; i < fixedInput.length; i++) {
			var num = fixedInput[i];
			var obj = { "myType": num, "mySeeds": -1, "myNum": curPuzzle[num].myNum, "effects": curPuzzle[num].effects, "decoyStatus": curPuzzle[num].decoyStatus };
			curCauldron.push(obj);
		}
		cSize = curCauldron.length;
	
	// otherwise, read the ingredients from the interface
	} else {		
		//
		// create combined list of ingredients + how many seeds they have
		//
		// (this reads the value of the dropdowns)
		for(var i = 0; i < cSize; i++) {
			curCauldron[i].mySeeds = parseInt(document.getElementById('ingredientSeeds' + i).value);
		}
	}

	// now step through the list and determine whatever happens
	var growingResult = '';
	var totalEffectResult = [];

	//
	// EXECUTE EFFECTS (+ find UNDERGROWN ingredients)
	// 
	//  => we go through the cauldron from OLDEST/FIRST element to the newest; order is important
	var numWrongIngredients = 0;
	var numUndergrown = 0;
	var numOvergrown = 0;
	var elementsConsidered = 0;

	var fertilizerActive = false;
	for(var i = 0; i < cSize; i++) {
		// if the number of seeds = -1, set it to whatever is necessary to make this ingredient report correctly
		if(curCauldron[i].mySeeds == -1) {
			curCauldron[i].mySeeds = curCauldron[i].myNum;
		}

		// check the ingredient!
		var checkResult = checkIngredient(i);

		var ing = curCauldron[i];
		var skipEvaluation = false;

		// if this ingredient is an IGNORE DECOY, well, ignore it
		if(ing.decoyStatus == 0) {
			skipEvaluation = true;
		}

		// a coward moves itself to the back of the potion
		// this means we skip evaluation now, and decrement the value of i
		var effs = checkResult.directEffects;
		if(effs['Coward']) {
			skipEvaluation = true;
			i--;
		}

		if(!skipEvaluation) {
			elementsConsidered++;

			// if it is undergrown, count that (and set ingredient to "wrong")
			if(ing.mySeeds < ing.myNum) {
				numUndergrown++;
				checkResult.isWrong = true;

				// if the fertilizer is active, count this ingredient as correct, then deactivate the fertilizer
				if(fertilizerActive) {
					numUndergrown--;
					checkResult.isWrong = false;
					fertilizerActive = false;
				}

			// if it is overgrown, also count that (and set ingredient to "wrong")
			} else if(ing.mySeeds > ing.myNum) {
				numOvergrown++;
				checkResult.isWrong = true;

				// if the fertilizer is active, count this ingredient as correct, then deactivate the fertilizer
				if(fertilizerActive) {
					numOvergrown--;
					checkResult.isWrong = false;
					fertilizerActive = false;
				}
			}

			// if something is wrong with this ingredient, count that
			if(checkResult.isWrong) {
				numWrongIngredients++;
			}
		}

		// add feedback to the effect feedback bar
		// also flatten feedback (in case an ingredient has multiple effects; otherwise they stay in order)
		for(var f = 0; f < checkResult.feedbackText.length; f++) {
			totalEffectResult.push( checkResult.feedbackText[f] );
		}

		//
		// if a DIRECT EFFECT must happen, do that
		//
		if(effs['Cutoff']) { break; } // cutoff immediately stops executing this potion
		if(effs['Enthusiastic']) { i++; } // skip the next element in line		
		if(effs['Fertilizer']) { fertilizerActive = true; } // the next overgrown/undergrown element is magically perfect

		// this completely resets the evaluation
		if(effs['Resetter']) {
			elementsConsidered = 0;
			numWrongIngredients = 0;
			totalEffectResult = [];

			numUndergrown = 0;
			numOvergrown = 0;
			fertilizerActive = false;
		}			
	}

	// combine results from growing
	growingResult = '<p>Potion had <strong>' + numUndergrown + ' undergrown</strong> and <strong>' + numOvergrown + ' overgrown</strong> ingredients.</p>';

	// shuffle effects and combine them into string as well
	totalEffectResult = shuffle(totalEffectResult);
	totalEffectResult = totalEffectResult.join("");

	//
	// determine if the players WON
	//  => if so, override all messages with a congratulatory one!
	//
	if(elementsConsidered >= codeLength && numWrongIngredients == 0) {
		growingResult = '';
		totalEffectResult = '<p class="winMessage">Congratulations! You won!</p>';

		// if we were testing solvability, return true here!
		if(fixedInput != null) {
			return true;
		}
	}

	if(fixedInput == null) {
		// display the results
		document.getElementById('potionResult').style.display = 'block';
		document.getElementById('potionResult').innerHTML = growingResult + totalEffectResult;

		// clear everything
		clearIngredients();
	}

	return false;
}

// when the "start game" button is clicked ...
document.getElementById('eventButton').addEventListener('click', function(ev) {
	// grab player count + difficulty level (input by user)
	playerCount = parseInt( document.getElementById('playerCount').value );
	difficulty = parseInt( document.getElementById('difficulty').value );

	// change some settings based on difficulty
	effectsLevel = 1;
	switch(difficulty) {
		case 0:
			numIngredients = 6;
			effectsLevel = 0;
			break;

		case 1:
			numIngredients = 6;
			break;

		case 2:
			numIngredients = 8;
			break;

		case 3:
			numIngredients = 8;
			variableRecipe = true;
			break;

		case 4:
			numIngredients = 8;
			variableRecipe = true;

		case 5:
			numIngredients = 10;
			effectsLevel = 2;
			variableRecipe = true;
			break;
	}

	// show a "loading" message (to let the user know it's doing something)
	document.getElementById('potionResult').style.display = 'block';
	document.getElementById('potionResult').innerHTML = '<p>Generating puzzle (may take a good thirty seconds) ... </p>';

	setTimeout(generatePuzzle, 50);
});

function generateFirstHint(type) {
	var txt = '<p>Here\'s a <strong>free clue</strong> to start the game!</p><p>';
	switch(type) {
		// reports a group of three elements
		// and either says "one of these is a decoy"
		// or "one of these has number X" (and thus is a good ingredient)
		case 'Group':
			var copyPuzzle = JSON.parse(JSON.stringify(curPuzzle));
			copyPuzzle = shuffle(copyPuzzle).splice(0,3);

			if(copyPuzzle[0].decoyStatus >= 0) {
				txt += 'One of these ingredients is a DECOY: ';
			} else {
				txt += 'One of these ingredients has number ' + copyPuzzle[0].myNum + ': ';
			}

			copyPuzzle = shuffle(copyPuzzle);
			txt += copyPuzzle[0].myName + ', ' + copyPuzzle[1].myName + ' or ' + copyPuzzle[2].myName;
			break;

		// picks one ingredient and states which number it is NOT
		case 'Negative':
			// pick a random ingredient
			var randNum = Math.floor(Math.random() * curPuzzle.length);
			var randIng = curPuzzle[randNum];
			txt += ingredientNames[randNum] + ' is NOT ';

			// if it's a non-imposter decoy, return any valid number
			// otherwise, report a lower number with 50% chance, or a higher number with 50% chance
			var realNum = randIng.myNum;
			if(realNum == -1 || realNum == 0 || realNum == (codeLength+1)) {
				txt += Math.floor(Math.random()*codeLength) + 1;
			} else {
				if(Math.random() <= 0.5) {
					txt += Math.floor(Math.random()*realNum);
				} else {
					txt += Math.floor(math.random()*(codeLength-realNum+1))+realNum+1;
				}
			}

			break;

		// pick one ingredient and state whether it has effects or not
		case 'Effects':
			var randIng = curPuzzle[Math.floor(Math.random() * curPuzzle.length)];
			txt += randIng.myName;

			// if effects aren't even enabled, ??
			if(effectsLevel == 0) {
				if(randIng.myNum <= 0) {
					txt += ' is a decoy';
				} else if(randIng.myNum <= Math.floor(0.5*codeLength)) {
					txt += ' should be in the first half of the potion';
				} else {
					txt += ' should be in the last half of the potion';
				}
				
			
			// if effects are enabled, return info here
			} else {
				txt += ' has ' + randIng.effects.length + ' effects ';
			}

			break;
	}

	txt += '</p>';
	return txt;
}

function generatePuzzle() {
	// THE BIG LOOP! Create puzzle, then check if it is solvable, rinse and repeat until done
	puzzleIsValid = false;
	do {
		createPuzzle();
		checkPuzzle();
	} while(!puzzleIsValid);

	// reset cauldron (otherwise we start from a wrong point, causing errors and crashes)
	curCauldron = [];

	// create a random FIRST HINT / FREE ADVICE
	// TO DO: I might want to make more hint types, for variety and all
	var hintTypes = ['Group', 'Negative', 'Effects'];
	var firstHintType = hintTypes[Math.floor(Math.random()*hintTypes.length)];
	document.getElementById('potionResult').innerHTML = generateFirstHint(firstHintType);

	// create the "list of ingredients" part of the interface
	// (player can click this to add something to the current cauldron)
	for(var i = 0; i < numIngredients; i++) {
		// create button
		var btn = document.createElement("button");
		btn.innerHTML = '<div class="ingSprite" style="background-position:' + (-120*i) + 'px;"></div>';

		// remember which ingredient this is
		btn.setAttribute('data-ing', i);
		btn.classList.add('ingButton');

		// add event listener => on click, add new ingredient of this type
		btn.addEventListener('click', function(ev) {
			addIngredient( parseInt(ev.currentTarget.getAttribute('data-ing')) );
		});		

		// add button to ingredient clicker
		document.getElementById("ingredientClicker").appendChild(btn);		
	}

	// hide this button
	document.getElementById('eventButton').style.display = 'none';

	// hide explanation text
	var owes = document.getElementsByClassName('onlineWitchExplanation')
	for(var i = 0; i < owes.length; i++) {
		owes[i].style.display = 'none';
	}

	// show all other areas (that are permanent)
	document.getElementById('effectsInPlay').style.display = 'block';
	document.getElementById('currentCauldron').style.display = 'block';
	document.getElementById('ingredientClicker').style.display = 'grid';
	document.getElementById('solutionRevealer').style.display = 'block';

	// and hide the potion result again => NO, with first hints active, we keep it visible
	// document.getElementById('potionResult').style.display = 'none';
}

// This is a recursive function that steps through ingredients, checking all possible combinations
// For each combination, it calls usePotion (or a faster variant of it) and checks the result
// If the potion was correct, exit the search and return true! Otherwise, it returns false.
function checkCombinationRecursive(comb) {
	// if we're at max code length, test the potion
	if(comb.length >= codeLength) {
		return usePotion(comb);
	}

	// otherwise, check all next ingredients
	// first, grab the last value (so we can reduce the number of combinations to check)
	var lastVal = -100;
	if(comb.length > 0) {
		lastVal = curPuzzle[ comb[comb.length - 1] ].myNum;
	}
	
	for(var i = 0; i < curPuzzle.length; i++) {
		// ignore elements that are too far apart to be in consecutive order
		// do NOT ignore "ignore" decoys if they have (at least) one effect
		if(lastVal != -100 && Math.abs(lastVal - curPuzzle[i].myNum) > 1 && !(curPuzzle[i].myNum == -1 && curPuzzle[i].effects.length > 0)) {
			continue;
		}

		// append new value to combination
		var newComb = JSON.parse(JSON.stringify(comb));
		newComb.push(i);

		// check the combination and report the result
		var result = checkCombinationRecursive(newComb);
		if(result) { 
			return true; 
		}
	}

	return false;
}

function checkPuzzle() {
	// Call the recursive function, starting with an empty cauldron/empty combination
	// (It will automatically check everything and return true/false accordingly)
	var result = checkCombinationRecursive([]);

	// permanently set whether the puzzle has a solution or not
	puzzleIsValid = result;
}

function createPuzzle() {
	// generate a random ordering of numbers
	var allNumbers = [];
	for(var i = 0; i < numIngredients; i++) {
		// these ingredients are part of the recipe, so give them numbers 1,...,n
		if(i < codeLength) {
			allNumbers[i] = (i+1);

		// these ingredients are not, so give them a -1 (this will be replaced with a proper decoy later)
		} else  {
			allNumbers[i] = -1;
		}
		
	}
	allNumbers = shuffle(allNumbers);

	for(var i = 0; i < numIngredients; i++) {
		var num = allNumbers[i];
		var effects = [];

		// let's determine a random decoy type (0,1,2)
		// 0 = IGNORE; this ingredient will be skipped and not interacted with, although effects execute
		// 1 = OVERACHIEVER; this ingredient is always undergrown (0) or overgrown (n+1)
		// 2 = IMPOSTER; this ingredient behaves like a regular ingredient, but it has the "imposter" effect
		var decoyStatus = -1;
		if(num == -1) {
			var randNum = Math.random();
			if(randNum <= 0.33 || difficulty < 2) {
				decoyStatus = 0;
			} else if(randNum <= 0.66) {
				decoyStatus = 1;

				if(Math.random() <= 0.5) {
					num = 0;
				} else {
					num = (codeLength+1);
				}
			} else {
				decoyStatus = 2;
				num = Math.floor(Math.random()*codeLength)+1;
				effects.push("Imposter");
			}
		}

		var obj = { "myName": ingredientNames[i], "myNum": num, "effects": effects, "decoyStatus": decoyStatus };
		curPuzzle[i] = obj;
	}

	// if effects are enabled ...
	//  => randomly distribute effects across the ingredients
	//  => shuffle them, grab X of them (however many needed)
	if(effectsLevel > 0) {
		// DEEP copy the effects array
		// (because we'll be adding/removing in a moment)
		var effectListCopy = JSON.parse(JSON.stringify(allEffects));

		// determine number of effects (based on number of ingredients + effects level)
		if(effectsLevel == 1) {
			numEffects = Math.floor(numIngredients*0.5);
		} else if(effectsLevel == 2) {
			numEffects = Math.floor(numIngredients*0.75);
		}

		// RETRIEVE this number of effects
		// there's a specific order to grabbing effects: 1) Change Cauldron, 2) Investigative, 3) Change Player, 4) Change Field, 5) Complex
		// once this order is exhausted, it starts picking stuff randomly, according to some probabilities
		var possibleEffectTypes = ['ChangeCauldron', 'Investigative', 'ChangePlayers', 'ChangeField'];
		var finalEffectList = [];
		finalEffectList[0] = shuffle(effectListCopy['ChangeCauldron']).splice(0, 1)[0];
		finalEffectList[1] = shuffle(effectListCopy['Investigative']).splice(0, 1)[0];
		finalEffectList[2] = shuffle(effectListCopy['ChangePlayers']).splice(0, 1)[0];
		finalEffectList[3] = shuffle(effectListCopy['ChangeField']).splice(0, 1)[0];
		if(effectsLevel >= 2) {
			finalEffectList[4] = shuffle(effectListCopy['Complex']).splice(0, 1)[0];
			possibleEffectTypes.push('Complex');
		}

		// now build a single list consisting of all types
		// (this automatically ensures that, when grabbing randomly, we have the right probabilities of grabbing each type)
		var bigEffectList = [];
		for(var i = 0; i < possibleEffectTypes.length; i++) {
			bigEffectList = bigEffectList.concat(effectListCopy[ possibleEffectTypes[i] ]);
		}

		// once the default order is done, as long as we don't have enough effects yet, grab them completely randomly
		while(finalEffectList.length < numEffects) {
			finalEffectList.push( bigEffectList.splice(0, 1)[0] );
		}

		// now apply them randomly
		// ALSO display the effects currently in play (visually; for explanation and an easier game)
		document.getElementById('effectsInPlay').innerHTML = '<p>Effects in play (tap them for explanation):</p>';
		for(var i = 0; i < finalEffectList.length; i++) {
			var curEffect = finalEffectList[i];

			// access a random ingredient
			// TO DO/QUESTION: Distribute this fairly (one effect per ingredient)?
			var randType = Math.floor(Math.random() * numIngredients);
			curPuzzle[randType].effects.push( curEffect.name );

			// some effects require the addition of more effects (on the same or other ingredients)
			// do this here
			if(curEffect.name == 'Brothers' || curEffect.name == 'Enemies') {
				var randTwin;
				do {
					randTwin = Math.floor(Math.random() * numIngredients);
				} while(randTwin == randType);
				curPuzzle[randTwin].effects.push( curEffect.name );
			}

			// create element to display the CLICKABLE event name
			var newElement = document.createElement('span');
			newElement.classList.add('effectName');
			newElement.innerHTML = curEffect.name;

			// event listener => grab event name from element itself, load explanation into correct element
			newElement.addEventListener('click', function(ev) {
				var effectName = ev.currentTarget.innerHTML;

				// if this is a second click, hide everything instead
				if(effectName == curEffectExplanationActive) {
					curEffectExplanationActive = null;
					document.getElementById('effectExplanations').style.display = 'none';
					return;
				}

				document.getElementById('effectExplanations').style.display = 'block';
				document.getElementById('effectExplanations').innerHTML = effectExplanations[effectName];
				curEffectExplanationActive = effectName;
			});

			document.getElementById('effectsInPlay').appendChild(newElement);

			// save the explanation for quick access
			effectExplanations[curEffect.name] = curEffect.explanation;
		}
	}
}

// add event listener to the "I've lost - show me the solution!" button
document.getElementById('solutionButton').addEventListener('click', function(ev) {
	// build the result
	var res = '';

	// go through all ingredients, give their name + number + any effects or decoy status
	var decoyNames = ['Ignore', 'Overachiever', 'Imposter'];
	for(var i = 0; i < numIngredients; i++) {
		var tempName = ingredientNames[i];
		var tempNum = ' = ' + curPuzzle[i].myNum;
		if(curPuzzle[i].myNum == -1) {
			tempNum = '';
		}

		var tempEffects = ' | Effects: ' + curPuzzle[i].effects.join(", ");
		if(curPuzzle[i].effects.length <= 0) {
			tempEffects = '';
		}

		var decoyType = '';
		if(curPuzzle[i].decoyStatus >= 0) {
			decoyType = ' | Decoy: ' + decoyNames[curPuzzle[i].decoyStatus];
		}

		res += '<p><strong>' + tempName + '</strong>' + tempNum + tempEffects + decoyType + '</p>';
	}

	// display result
	document.getElementById('potionResult').style.display = 'block';
	document.getElementById('potionResult').innerHTML = res;
});

// add event listener to the "Use Potion!" button
document.getElementById('usePotionButton').addEventListener('click', function(ev) {
	// well, simply call the usePotion function
	usePotion();
});