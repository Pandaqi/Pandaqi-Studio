<?php
	require '../../default_headers.php';
?>
		<title>Tower of Freedom&mdash;Build a tower together, find your freedom</title>
		<link rel="icon" type="image/png" href="gamesites/tower-of-freedom/favicon.png" />

		<link href="https://fonts.googleapis.com/css?family=Fredoka+One" rel="stylesheet"> 
		<link href="https://fonts.googleapis.com/css?family=Catamaran:400,900&display=swap" rel="stylesheet">

		<style type="text/css">
			body {
				background-repeat: repeat;
				font-family: 'Catamaran';
				font-size: 20px;
				line-height: 120%;
			}

			main {
				max-width: 900px;
				margin: auto;
			}

			#gameHeader {
				text-align: center;
				display:none;
			}

			#gameHeader > img {
				max-width: 100%;
			}

			.gifContainer {
				max-width: 100%;
				box-sizing: border-box;
			}

			.videoContainer, .gifContainer {
				border: 20px solid #2D4E31;
				border-radius: 0.5em;
				box-shadow: 0 0 30px 10px #23120B;
				box-sizing: border-box;
			}

			.videoContainer {
				position:relative;
				padding-bottom:56.25%;
				padding-top:30px;
				height:0;
				overflow:hidden;
			}

			.videoContainer iframe, .videoContainer object, .videoContainer embed {
				position:absolute;
				top:0;
				left:0;
				width:100%;
				height:100%;
			}

			h1 {
				font-family: 'Catamaran';
				font-weight: 900;
				/*text-align: center;*/
				font-size:42px;
				margin-bottom: 0px;
				margin-top:0px;
				text-transform: none;

				color: #330000;

				background-color: #4A3521;
				color: white;
				padding: 20px;

				display: inline-block;
				border-radius: 0.5em;

				text-decoration: none;
				margin-top: -60px;
			}

			.buyLink {
				margin-top:0px;
				display: inline-block;
				padding: 20px;
				background-color: #4A3521;
				color: white;
				border-radius:0.5em;
				text-decoration: none;
				font-family: 'Catamaran';
				font-weight: 900;

				transition: background-color 0.5s, color 0.5s;
				box-shadow: 0 0 10px 2px #333;
			}

			.buyLink:hover {
				background-color: white;
				color: #333;
			}

			.horizontalFlex {
				display: flex;
				align-items: center;
				position: relative;
			}

			.horizontalFlex > div {
				width: 50%;
				box-sizing: border-box;
			}

			.horizontalFlex .textSide {
				padding: 10px;
				padding-top: 0px;
			}

			.horizontalFlex .textSide p:first-child {
				margin-top:0px;
			}

			.horizontalFlex .nonTextSide {
				margin-right: 20px;
				text-align: center;

				margin-bottom: 10px;
			}

			.screenshotGallery {
				height: 240px;
				overflow-x: scroll;
				overflow-y: hidden;
				white-space: nowrap;
				box-sizing: border-box;
			}

			.screenshotGallery > div {
				display: inline-block;
				height: 240px;
				white-space: nowrap;
				margin: 0px;
				box-sizing: border-box;
			}

			.screenshotGallery > div > img {
				max-height: auto;
			}

			main a {
				display:block;
				padding: 20px;
				background-color: #0E6A43;
				color: white;
				border-radius:0.5em;
				text-decoration: none;
				font-family: 'Fredoka One';

				transition: background-color 0.5s, color 0.5s;
				box-shadow: 0 0 10px 2px #333;
			}

			main a:hover {
				background-color: white;
				color: #333;
			}

			.screenshotGalleryContainer {
				 background-color: #4A3521; 
				 padding: 50px; 
				 margin-top: 70px;
			}

			.questContainer {
				line-height: 120%;
			}

			@media all and (max-width: 900px) {
				.horizontalFlex {
					flex-wrap: wrap;
				}

				.horizontalFlex > div {
					width: 100%;
				}

				.horizontalFlex .nonTextSide {
					margin-right: 0px;
				}

				.imageRight {
					flex-direction: column-reverse;
				}
			}

			@media all and (max-width: 600px) {
				p {
					padding-left: 10px !important;
					padding-right: 10px !important;
					box-sizing: border-box;
				}

				.screenshotGalleryContainer {
					padding-left:0px;
					padding-right: 0px;
				}

				#gameHeader {
					display:block;
				}
			}
		</style>

		<!--
		GOLDEN RULES OF LANDING PAGES:
		 -> No navigation (people will click through, get distracted, clutters the page)
		 -> Big, wide images that show off your game
		 -> Start with trailer or animated GIF (that shows game as quickly as possible)
		 		=> HOLY GRAIL: (autoplay) trailer inside a big wide header image!
		 -> Put download buttons above the fold/as high as you can => the page was designed to make people download/buy, so use it in that way
		 -> Add some movement, but keep it simple otherwise => very simple but clean landing pages are known to sell better
		 -> Add a press kit; maybe not at the top, but somewhere it's easy to find

		 -> Add quotes/reviews as early as you can (and make them look nice and like your game is absolutely amazing)
		       => Social proof is really powerful

		 -> When you add screenshots, make sure they are from different settings and don't look very similar. (Maybe even different color palette.)

		-->
	</head>

	<body>
		<section style="background-image:url('https://i.imgur.com/vlqWMiF.png'); background-size: cover; position: relative;">
			<div style="position:absolute;width:100%;height:100%;background-color:rgba(0,0,0,0.5);"></div>
			<div style="max-width: 600px; margin: auto; padding-top:100px; padding-bottom: 100px;">
				<div class="videoContainer">
					<iframe src="https://www.youtube.com/embed/rRJRZrNZp1E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>
			</div>
		</section>

		<div style="position: relative;">

			<section style="text-align:center;margin-top:-30px;">
				<a href="http://pandaqi.itch.io/tower-of-freedom" class="buyLink">Download "Tower of Freedom" (free)</a>
				<p style="margin-top:0px; color: #333; margin-bottom:60px;">(Windows, Mac, Linux)</p>
			</section>

			<section style="max-width: 600px; margin: auto;">
				<p>Grab the right tools and resources, and build your tower to the portal!</p>
				<p>Chop trees and break stones to get the right resources for a strong tower. However, beware of monsters trying to tear you and your tower apart! Balance constructing and resource gathering with killing those sneaky monsters, and you will succeed.</p>
				<p>(And go into the history books as the Greatest Builder of Towers that ever existed. I know you want it.)</p>
			</section>

		</div>

		<section style="background-image:url('https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI2Ny5wbmc=/794x1000/Ukzwpb.png');">
			<div style="max-width: 600px; margin: auto; padding: 30px; color: white; margin-top: 70px; text-shadow: 0 0 3px black;">
				<div style="text-align: center; margin-top:-35px;"><h1>Features</h1></div>
				<p>There's an interactive tutorial to learn the game, a local multiplayer mode, and a single player mode.</p>
				<p>Also ...</p>
				<ul>
					<li>Six tools to choose from</li>
					<li>Three resources to gather</li>
					<li>Four monsters to battle</li>
						<li>Two modes to play (day and night)</li>
					<li>Ten difficulty levels and ten map sizes</li>
					<li>Nine items to buy in the shop (during a game)</li>
				</ul>
			</div>
		</section>

		<section style="max-width: 600px; margin: auto;">
			<p>This game is one of the first "professional" games made with the Godot game engine. As such, it indirectly got me a job as co-writer on one of the first books about this engine.</p>
			<p><em>Why is "professional" between quotes?</em> Because the game looks awesome, but it's nowhere near the scope and polish of a professional game. I kept the game really small and simple, and spent almost all my time on the graphics. The game is still loads of fun, just don't expect to sink 10+ hours into it :p</p>
			<p>The game is finished, but nothing is perfect. If you have suggestions, improvements, bugs, just let me know!</p>

		</section>

		<div class="screenshotGalleryContainer">
			<div style="text-align: center; margin-top:-55px;"><h1>Screenshots</h1></div>
			<section class="screenshotGallery">
				<div><img src="https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI1NS5wbmc=/794x1000/BI4rGT.png" /></div>
				<div><img src="https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI2Ni5wbmc=/794x1000/Dd5s7V.png" /></div>
				<div><img src="https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI2NS5wbmc=/794x1000/Ug4eDz.png" /></div>
				
				<div><img src="https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI3NS5wbmc=/794x1000/V6NBb8.png" /></div>
				<div><img src="https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI3Ny5wbmc=/794x1000/a%2BpZ8C.png" /></div>
				<div><img src="https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI3Ni5wbmc=/794x1000/GFRx7%2B.png" /></div>
				<div><img src="https://img.itch.zone/aW1hZ2UvMTAwMDg0LzQ5NDI3OC5wbmc=/794x1000/nY4ZmK.png" /></div>
			</section>
		</div>


<?php

require '../../footer.php';

?>

		