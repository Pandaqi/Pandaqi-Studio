const NODE_ACTION_TYPES = ['Cutting', 'Turn', 'Modify', 'Movement', 'Progression', 'Blocking', 'Ownership']
const NODE_CATEGORIES = 
{
	'Plants': 
		{
			color: 0x7BF1A8,
			lightColor: 0x94E59E,
		},

	'Nature':
		{
			color: 0x009FB7,
			lightColor: 0xC2DDF7,
		},

	'Magical':
		{
			color: 0xFED766,
			lightColor: 0xFFEBAF,
		},

	'Enemies':
		{
			color: 0xE08D79,
			lightColor: 0xFEAB97,
		},

	'Resources':
		{
			color: 0xEFF1F3,
			lightColor: 0xFFFFFF,
		},

	'Misc':
		{
			color: 0xA882DD,
			lightColor: 0xDAC9F2,
		},

	'Technology':
		{
			color: 0x8C7A6B,
			lightColor: 0xFFD2AC,
		},

	'Center':
		{
			color: 0xFFD6E0,
			lightColor: 0xFF9EB6,
		}
}


var NODES, MISSION_NODES, EXPEDITION_NODES

/* big dictionary of nodes

@parameters: 
 - min: minimum number of times this type should appear on the board
 - prob: probability of appearing (relative to total)
 - forbiddenOnEdge: whether this node may appear on the edge of the board

*/
const NODES_DICT = {
	'Center':
		{
			prob: 0,
			category: 'Center',
			actionTypes: [],
			iconFrame: 0
		},

	'Oil':
		{
			min: 5,
			prob: 5,
			category: 'Resources',
			actionTypes: ['Cutting'],
			iconFrame: 1
		},

	'Fish':
		{
			min: 3,
			prob: 3,
			category: 'Nature',
			actionTypes: ['Turn'],
			iconFrame: 2,

			maxSequence: 1,
		},

	'Water':
		{
			min: 5,
			prob: 5,
			category: 'Nature',
			actionTypes: ['Movement'],
			maxSequence: 4,
			iconFrame: 3,

			maxDistanceFromEdge: 2,
		},

	'Wood': 
		{
			min: 3,
			prob: 3,
			category: 'Technology',
			actionTypes: ['Cutting'],
			iconFrame: 4
		},

	'Fruit':
		{
			min: 6,
			prob: 3,
			category: 'Plants',
			actionTypes: ['Cutting'],
			iconFrame: 5,

			requirements: ['Dynamite']
		},

	'Dynamite':
		{
			min: 4,
			max: 7,
			prob: 3,
			category: 'Enemies',
			actionTypes: ['Modify'],
			iconFrame: 6
		},

	'Stardust':
		{
			min: 6,
			prob: 3,
			category: 'Magical',
			actionTypes: ['Progression'],
			iconFrame: 7,

			requirements: ['Critters'],
		},

	'Critters':
		{
			min: 5, 
			prob: 5,
			category: 'Enemies',
			actionTypes: ['Progression'],
			iconFrame: 8,

			forbiddenOnEdge: true,
			minDistanceFromEdge: 2,
			maxSequence: 1,

			needsNumber: true,
			typeNeeded: 'Stardust',

			requirements: ['Stardust']
		},

	'Puppy':
		{
			min: 2,
			max: 5,
			prob: 3,
			category: 'Misc',
			actionTypes: ['Blocking'],
			maxSequence: 1,
			iconFrame: 9
		},

	/*
	'Twinbird':
		{
			min: 3,
			max: 4,
			prob: 3,
			category: 'Nature',
			actionTypes: ['Ownership'],
			maxSequence: 1,
			iconFrame: 10
		},
	*/

	//
	// Nasty Nodes (Expansion)
	//
	'Clock':
		{
			min: 3,
			max: 5,
			prob: 3,
			category: 'Magical',
			actionTypes: ['Turn'],
			maxSequence: 1,
			iconFrame: 11,

			expansion: 'Nasty Nodes',
		},

	'Critter Boss':
		{
			min: 1,
			max: 3,
			prob: 3,
			category: 'Enemies',
			actionTypes: ['Progression'],
			maxSequence: 1,
			iconFrame: 12,

			forbiddenOnEdge: true,
			minDistanceFromEdge: 2,

			needsNumber: true,
			typeNeeded: 'Critters',

			expansion: 'Nasty Nodes',

			requirements: ['Critters'],
		},

	'Leapfrog':
		{
			min: 3,
			prob: 4,
			category: 'Nature',
			actionTypes: ['Movement'],
			iconFrame: 13,

			expansion: 'Nasty Nodes',
			requirements: ['Clock']
		},

	'Stone':
		{
			min: 2,
			prob: 2,
			category: 'Resources',
			actionTypes: ['Ownership'],
			maxSequence: 1,
			iconFrame: 14,

			expansion: 'Nasty Nodes',
		},

	'Shield':
		{
			min: 1,
			max: 3,
			prob: 3,
			category: 'Misc', 
			actionTypes: ['Blocking'],
			maxSequence: 1,
			iconFrame: 15,

			expansion: 'Nasty Nodes',
		},

	'Fire':
		{
			min: 1,
			max: 4,
			prob: 3,
			category: 'Technology',
			actionTypes: ['Cutting', 'Modify'],
			maxSequence: 1,
			iconFrame: 16,

			expansion: 'Nasty Nodes',
			requirements: ['Wood', 'Oil']
		},

	'Poison':
		{
			min: 1,
			max: 5,
			prob: 3,
			category: 'Plants',
			actionTypes: ['Blocking'],
			iconFrame: 17,

			expansion: 'Nasty Nodes',
			requirements: ['Healing']
		},

	'Healing':
		{
			min: 1,
			max: 5,
			prob: 3,
			category: 'Plants',
			actionTypes: ['Cutting'],
			iconFrame: 18,

			expansion: 'Nasty Nodes',
			requirements: ['Poison']
		},

	'Parasite':
		{
			min: 2,
			max: 5,
			prob: 4,
			category: 'Nature',
			actionTypes: ['Cutting'],
			iconFrame: 19,

			expansion: 'Nasty Nodes',
		},

	//
	// Nodes of Knowledge
	// 
	'Sun':
		{
			min: 4,
			max: 7,
			prob: 5,
			category: 'Technology',
			actionTypes: ['Cutting', 'Progression'],
			iconFrame: 20,

			expansion: 'Nodes of Knowledge',
			requirements: ['Moon'],
			maxSequence: 1,
		},

	'Moon':
		{
			min: 4,
			max: 7,
			prob: 5,
			category: 'Resources',
			actionTypes: ['Cutting', 'Progression'],
			iconFrame: 21,

			expansion: 'Nodes of Knowledge',
			requirements: ['Sun'],
			maxSequence: 1,
		},

	'Knowledge':
		{
			min: 2,
			max: 4,
			prob: 3,
			category: 'Misc',
			actionTypes: ['Turn'],
			iconFrame: 22,

			expansion: 'Nodes of Knowledge'
		},

	'Black Matter':
		{
			min: 3,
			max: 6,
			prob: 5,
			category: 'Magical',
			actionTypes: ['Modify', 'Movement'],
			iconFrame: 23,

			expansion: 'Nodes of Knowledge'
		},

	'Chameleon':
		{
			min: 2,
			max: 5,
			prob: 3,
			category: 'Nature',
			actionTypes: ['Ownership'],
			iconFrame: 24,

			expansion: 'Nodes of Knowledge'
		},

	'Night Owl':
		{
			min: 2,
			max: 5,
			prob: 5,
			category: 'Enemies',
			actionTypes: ['Cutting'],
			iconFrame: 25,

			expansion: 'Nodes of Knowledge',
			requirements: ['Sun', 'Moon']
		},

	'Curse':
		{
			min: 2,
			max: 4,
			prob: 4,
			category: 'Magical',
			actionTypes: ['Turn'],
			iconFrame: 26,

			expansion: 'Nodes of Knowledge',
			requirements: ['Wall Plant'],
			maxSequence: 1,
		},

	'Wall Plant':
		{
			min: 2,
			max: 4,
			prob: 4,
			category: 'Plants',
			actionTypes: ['Modify', 'Blocking'],
			iconFrame: 27,

			expansion: 'Nodes of Knowledge',
			requirements: ['Curse'],
			maxSequence: 1,
		},

	'Village Ruins':
		{
			min: 2,
			max: 4,
			prob: 4,
			category: 'Misc',
			actionTypes: ['Ownership'],
			iconFrame: 28,

			expansion: 'Nodes of Knowledge',
			maxSequence: 1,
		},

	//
	// The Electric Expansion
	// TO DO: Requirements and better probabilities/min-max

	'Electricity':
		{
			min: 6,
			max: 10,
			prob: 3,

			category: 'Technology',
			actionTypes: ['Progression'],
			iconFrame: 30,

			expansion: 'The Electric Expansion',
			maxSequence: 1,

			requirements: ['Battery', 'Shovel', 'Factory']
		},

	'Battery':
		{
			min: 3,
			max: 5,
			prob: 4,

			category: 'Magical',
			actionTypes: ['Progression'],
			iconFrame: 31,

			expansion: 'The Electric Expansion',

			requirements: ['Electricity', 'Shovel', 'Factory']
		},

	'Shovel':
		{
			min: 6,
			max: 10,
			prob: 4,

			category: 'Magical',
			actionTypes: ['Progression'],
			iconFrame: 32,

			expansion: 'The Electric Expansion',
			maxSequence: 1,

			requirements: ['Electricity', 'Battery', 'Factory']
		},

	'Factory':
		{
			min: 3,
			max: 5,
			prob: 4,

			category: 'Misc',
			actionTypes: ['Turn', 'Movement', 'Ownership', 'Modify'],
			iconFrame: 33,

			expansion: 'The Electric Expansion',

			requirements: ['Electricity', 'Battery', 'Shovel']
		},

	'Electric Shield':
		{
			min: 3,
			max: 5,
			prob: 4,

			category: 'Misc',
			actionTypes: ['Blocking'],
			iconFrame: 34,

			expansion: 'The Electric Expansion'
		},

	'Wind':
		{
			min: 3,
			max: 5,
			prob: 4,

			category: 'Misc',
			actionTypes: ['Movement', 'Cutting'],
			iconFrame: 35,

			expansion: 'The Electric Expansion'
		},

	'Dragon Dino':
		{
			min: 1,
			max: 3,
			prob: 4,

			needsNumber: true,
			typeNeeded: 'Electricity',

			category: 'Enemies',
			actionTypes: ['Progression'],
			iconFrame: 36,

			expansion: 'The Electric Expansion',

			forbiddenOnEdge: true,
			minDistanceFromEdge: 2,

			requirements: ['Electricity']
		},

	'Untamed Wildlands':
		{
			min: 2,
			max: 5,
			prob: 2,

			category: 'Nature',
			actionTypes: ['Cutting', 'Blocking'],
			iconFrame: 37,

			expansion: 'The Electric Expansion'
		},

	'Biomass':
		{
			min: 3,
			max: 6,
			prob: 4,

			category: 'Plants',
			actionTypes: ['Cutting', 'Turn'],
			iconFrame: 38,

			expansion: 'The Electric Expansion',

			requirements: ['Electricity']
		},
};

const MISSION_NODES_DICT = 
{
	'Preserver': 
	{
		prob: 1,
		color: 0x009FB7,
		lightColor: 0xC2DDF7,
		iconFrame: 0
	},

	'Peacemaker':
	{
		prob: 1,
		color: 0xE08D79,
		lightColor: 0xFEAB97,
		iconFrame: 1,

		relevantNodes: ['Dynamite', 'Fire', 'Gas']
	},

	'Fighter':
	{
		prob: 1,
		color: 0xEFF1F3,
		lightColor: 0xFFFFFF,
		iconFrame: 2,

		relevantNodes: ['Critters', 'Critter Boss', 'Night Owl', 'Dragon Dino']
	},

	'Traveler':
	{
		prob: 1,
		color: 0x8C7A6B,
		lightColor: 0xFFD2AC,
		iconFrame: 3
	},

	'Biologist':
	{
		prob: 1,
		color: 0x7BF1A8,
		lightColor: 0x94E59E,
		iconFrame: 4
	},

	'Collector':
	{
		prob: 1,
		color: 0xA882DD,
		lightColor: 0xDAC9F2,
		iconFrame: 5
	},

	'Explorer':
	{
		prob: 1,
		expansion: 'Extreme Expeditions',
		color: 0xFED766,
		lightColor: 0xFFEBAF,
		iconFrame: 6
	},

	'Digger':
	{
		prob: 1,
		expansion: 'Sharp Scissors',
		color: 0xFFD6E0,
		lightColor: 0xFF9EB6,
		iconFrame: 7
	},

	'Conquerer':
	{
		prob: 1,
		expansion: 'Nodes of Knowledge',
		color: 0xA23E48,
		lightColor: 0xF6A7A3,
		iconFrame: 8
	},

	'Destroyer':
	{
		prob: 1,
		color: 0x37392E,
		lightColor: 0xEEFFA3,
		iconFrame: 9,
		expansion: 'Nasty Nodes'
	}
}

const EXPEDITION_NODES_DICT = 
{
	'Research Race':
	{
		prob: 1,
		expansion: "Extreme Expeditions",
		iconFrame: 1
	},

	'Trap':
	{
		prob: 1,
		expansion: "Extreme Expeditions",
		iconFrame: 2
	},

	'Follow the Leader':
	{
		prob: 1,
		expansion: "Extreme Expeditions",
		iconFrame: 3
	},

	'Whirlpool':
	{
		prob: 1,
		expansion: "Extreme Expeditions",
		iconFrame: 4
	},

	'Refurbished Objects':
	{
		prob: 1,
		expansion: "Extreme Expeditions",
		iconFrame: 5
	},

	'Underground Disaster':
	{
		prob: 1,
		expansion: "Extreme Expeditions",
		iconFrame: 6
	},

	'Second Chance':
	{
		prob: 1,
		expansion: "Extreme Expeditions",
		iconFrame: 7
	},
}

// NOTE: no need to create a dictionary for this and then copy, as this is always the same
const TINY_NODES = 
{
	'Circle':
	{
		prob: 4,
		iconFrame: 0
	},

	'Pause':
	{
		prob: 2,
		iconFrame: 2
	},

	'Square':
	{
		prob: 3,
		iconFrame: 1
	},

	'Triangle':
	{
		prob: 1.5,
		iconFrame: 3
	},

	'Cross':
	{
		prob: 2,
		iconFrame: 4
	}
}

// NOTE: Same
const NATURAL_RESOURCES = 
{
	'Coal':
	{
		prob: 2,
		iconFrame: 0
	},

	'Diamonds':
	{
		prob: 2,
		iconFrame: 1
	},

	'Gold':
	{
		prob: 2,
		iconFrame: 2
	},

	'Minerals':
	{
		prob: 2,
		iconFrame: 3
	},

	'Gas':
	{
		prob: 2,
		iconFrame: 4
	}
}

const LANDMARKS =
{
	'Mountain':
	{
		prob: 2,
		iconFrame: 0
	},

	'Forest':
	{
		prob: 2,
		iconFrame: 1
	},

	'Lake':
	{
		prob: 2,
		iconFrame: 2
	},

	'Capital':
	{
		prob: 2,
		iconFrame: 3
	},

	'Caves':
	{
		prob: 2,
		iconFrame: 4
	},
}