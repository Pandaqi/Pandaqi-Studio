Name: Giger

Author : Rodrigo Araya Salas

Lenguage: Basic Latin, Western European, Euro, Catalan, Baltic, Turkish, Central European,
Romanian, Pan African Latin, Dutch, Afrikaans, Latin Ligatures,Basic Cyrillic

Licence : Free for use personal, Free for use of  Students

Concept: has 2 meanings one is to be a tribute to the great artist Hans Rudolf Giger (Giger) 
Aliens and Author of several books and also a typeface that was special for brand design

Words: Thanks for all the emails and the people who always support me,
             if you want to donate so I can keep creating, thanks

web:  www.Rodrigotypo.com
         www.behance.net/rasdesign
